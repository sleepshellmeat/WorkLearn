



# Scala基础

## 回顾：

## 今天任务：

了解scala，

学习scala的基础语法，

学习scala中的数组、映射、元组、集合，

学习类及其相关概念。

## 教学目标：

了解scala语言，

搭建scala的开发环境，

能使用scala语言完成简单的程序。

## 1. 了解Scala

### 1.1 什么是 Scala

Scala 是 Scalable Language 的简写，是一门多范式的编程语言。

Scala设计的初衷是要集成面向对象编程和函数式编程的各种特性。Scala运行于Java平台（Java虚拟机），并兼容现有的Java程序。

函数式编程两种理念：就是一种抽象程度很高的编程范式，纯粹的函数式编程语言编写的函数没有变量，因此，任意一个函数，只要输入是确定的，输出就是确定的，这种纯函数我们称之为没有副作用。而允许使用变量的程序设计语言，由于函数内部的变量状态不确定，同样的输入，可能得到不同的输出，因此，这种函数是有副作用的。

函数式编程的一个特点就是，函数也是值，同允许把函数本身作为参数传入另一个函数，还允许返回一个函数！

![](scala1.png)

### 1.2 Scala特点

**Scala 是面向对象的**

Scala是一个纯面向对象的语言,所有的值都是对象,类和对象行为用类和特质来描述.

**Scala 是函数式的**

Scala中函数是高等公民,所有函数都是值.

**Scala是静态类型的**

![](ss.jpg)

**Scala 是可扩展的**

### 1.3 为什么要学Scala

1.优雅：这是框架设计师第一个要考虑的问题，框架的用户是应用开发程序员，API是否优雅直接影响用户体验。

2.速度快：Scala语言表达能力强，一行代码抵得上Java多行，开发速度快；Scala是静态编译的，所以和JRuby，Groovy比起来速度会快很多。

3.能融合到Hadoop生态圈：Hadoop现在是大数据事实标准，Spark并不是要取代Hadoop，而是要完善Hadoop生态。JVM语言大部分可能会想到Java，但Java做出来的API太丑，或者想实现一个优雅的API太费劲。

![](scala2.jpg) 



## 2 环境准备

### 2.1 JDK安装

因为Scala是运行在JVM平台上的，所以安装Scala之前要安装JDK

### 2.2 Scala安装

下载Scala地址https://downloads.lightbend.com/scala/2.11.12/scala-2.11.12.tgz然后解压Scala到指定目录

tar -zxvf scala-2.10.6.tgz -C /usr/java

配置环境变量，将scala加入到PATH中

```shell
vi /etc/profile

export JAVA_HOME=/usr/java/jdk1.7.0_45

export PATH=$PATH:$JAVA_HOME/bin:/usr/java/scala-2.10.6/bin
```

### 2.3. Scala开发工具安装

目前Scala的开发工具主要有两种：Eclipse和IDEA，这两个开发工具都有相应的Scala插件，如果使用Eclipse，直接到Scala官网下载即可http://scala-ide.org/download/sdk.html。

 

由于IDEA的Scala插件更优秀，大多数Scala程序员都选择IDEA，可以到https://www.jetbrains.com/idea/download/ 下载社区免费版，点击下一步安装即可，安装时如果有网络可以选择在线安装Scala插件。这里我们使用离线安装Scala插件：

 

1.安装IDEA，点击下一步即可。由于我们离线安装插件，所以点击Skip All and Set Defaul

2.下载IEDA的scala插件，地址http://plugins.jetbrains.com/plugin/1347-scala

3.安装Scala插件：File -> settings -> Plugins -> Install plugin from disk -> 选择Scala插件 -> OK -> 重启IDEA

![](scala4.png) 

## 3. Scala基础

### 3.1. 值和变量

使用var 声明一个变量。

- scala语言是强类型语言。
- var修饰的变量，内容和引用都可变

使用val声明一个常量或值

- val修饰的变量是不可变的，注意不可变的不是内容，而是引用；

- val修饰的变量，相当于Java中final修饰的变量；

- 只有val修饰的变量才能被lazy修饰；使用lazy定义变量后，只有在调用该变量时才会实例化这个变量的值。而且惰性变量只能是不可变变量；

```scala
//变量定义方式
var a:int = 1
var aa = 1
val aaa:Int = 3
val aaaa = 4
lazy val aaaaa = 4
```
官方推荐使用val。

**2.val和var区别示意:**

可以使用数组，更容易懂

```scala
class A(n: Int) {
 var value = n
}

class B(n: Int) {
 val value = new A(n)
}

object Test {
 def main(args: Array[String]) {
 val x = new B(5)
 x = new B(6) // 错误?
 x.value = new A(6) // 错误?
 x.value.value = 6 // 正常
 }
}

```

**3.lazy**

类似方法,先声明,后调用

![](lazy.png)

**4.val or var**

在val和var均可的条件下，官方推荐使用val

### 3.2. 常用类型

Scala和Java一样，有7种数值类型Byte、Char、Short、Int、Long、Float、Double和一个Boolean类型，

和Java不同的是 ，Scala没有基本类型与包装类型之分，这些类型都是类，有自己的属性和方法。

**相当于Java的包装类；**

1.toString()

1.to (10)

scala类型层级关系:

scala中所有的值都有类型,包括数值和函数.

![](unified-types-diagram.svg)



scala 类型转换：

![](type-casting-diagram.svg)

```scala
    val x: Long = 987654321
    val y: Float = x  // 9.8765434E8 (note that some precision is lost in this case)

    val face: Char = '☺'
    val number: Int = face  // 9786
```

### 3.3. 操作符

Scala中没有操作符，只是以操作符的格式去进行方法调用。

>> ```scala 
>> //数学运算符
>> +、-、* 、/、%
>> //关系操作符
>> > < >= <= !
>> //逻辑操作符
>> && ||
>> //位操作符
>> | & ^ ~
>> //比较对象是否相等
>> == ！=
>> ```

注意：

1. a + b 等价于 a.+(b)


2. Scala没有++，--  可以用+=，-=代替
3. 操作符都是方法的重载，是方法的调用

### 3.3. 条件表达式

**表达式：一个具有执行结果的代码块。结果是具体的值或者（）**

*表达式的思考方式：以表达式为中心的编程思想*

*1.表达式和语句的区别：表达式有返回值，语句被执行。表达式一般是一个语句块，执行后，返回一个值*

*2.不使用return语句，最后一个表达式即返回值*

if/else表达式有值，这个值就是跟在if或者else之后的表达式的值

```scala
object ConditionDemo {
  def main(args: Array[String]){
    var x = 1
    //将if/else表达式值赋给变量y
    val y = if (x > 0 ) 1 else -1
    println(y)

    //支持混合型表达式
    //返回类型是Any
    val z = if(x>0) "success"  else  -1
    println(z)

 
    //如果缺失else，相当于if(x>2) 1 else （）
    //返回类型是AnyVal
    //如果进行类型判断和转换，可以使用：
    //var b = if(m.isInstanceOf[Int]) m.asInstanceOf[Int] else 0
    val m = if(x>2) 1
    println(m)

    //在scala中，每个表达式都有值，scala中有个unit类，写作（），相当于Java中的 void
    val n = if(x>2) 1 else ()
    println(n)
    

    //if 嵌套
    val  k= if(x<0) 0 else if (x>=1) 1 else -1
    println(k)

  }
```

执行结果：

![](res1.png)

Scala的的条件表达式比较简洁，例如：

 注意：1，每个表达式都有一个类型

​            2，条件表达式有值

​            3，混合型表达式，结果是Any或者AnyVal

​            4，scala没有switch语句

### 3.4. 块表达式

```scala
object BlockExpressionDemo {
  def main(args: Array[String]){

    var x = 0

    //在scala中，{}中可以包含一系列表达式，块中最后一个表达式的值就是块的值
    val res = {
      if (x < 0) {
        -1
      } else if (x >= 1) {
        1
      } else {
        "error"
      }
    }
      println(res)

      val x0 = 1
      val y0 = 1
      val x1 = 2
      val y1 = 2
      val distance = {
        val dx = x1 - x0
        val dy = y1 - y0
        Math.sqrt(dx*dx+dy*dy)
      }
      println(distance)

    //块语句，最后一句是赋值语句，值是unit类型的

     var res2 = {
       val dx = x1 - x0
       val dy = y1 - y0
      val res =  Math.sqrt(dx*dx+dy*dy)
     }
    println(res2)
    
  }

}
```

执行结果：

![](res2.png)

注意：

1，块表达式的值是最后一个表达式的值

2，赋值语句的值是unit类型的，

### 3.5. 循环

在scala中有for循环和while循环，用for循环比较多

for循环语法结构：**for **(i <- 表达式/数组/集合)

while (条件语句){表达式}

do{ 表达式}while（）

```scala
object ForDemo 
  def main(args: Array[String]){
    //每次循环将区间的一个值赋给i
    for( i <- 1 to 10)
      println(i)

    //for i <-数组
    val arr = Array("a", "b", "c")
    for( i <- arr)
      println(i)

    val s = "hello"
    for(i <- 0 until s.length){
      println(s(i))
    }
    //  或者
    //   for(c <- s)println(c)
    //  或者
    //  for(i <- 0 until s.length){
    //  println(s.charAt(i))
    //使用了隐式转换，把字符串变成一个ArrayCharSequence 
    // }
      
    //高级for循环
    for(i <- 1 to 3 ; j<- 1 to 3 if i != j)
      print((10*i + j) + "")
      println()

    //for推导式，如果for循环的循环体以yeild开始，则该循环会构建出一个集合或者数组，每次迭代生成其中的一个值。
    val v= for ( i <- 1 to 10 )yield i*10
            println (v)
      
    //也可以借助函数由初始数组生成一个新的数组
      val arr1 = Array(1,2,3,4,5,6,7,8,9)
      val arr2 = arr.map(_*10)
      val arr3 = arr.filter(_%2==0)
      
      
  }
}
```

### 3.6. 定义方法和函数

#### 3.6.1. 定义方法

定义方法的基本格式是：

```
def 方法名称（参数列表）：返回值类型 = 方法体 
```

```scala
def add(x: Int, y: Int): Int = x + y
println(add(1, 2)) // 3
//也可以定义成
//def add(x: Int, y: Int) = x + y
//或者
//def add(x: Int, y: Int){x + y}，没有返回值，一定要用大括号把方法体括起来
```

带有多参数列表的方法:

```scala
def addThenMultiply(x: Int, y: Int)(multiplier: Int): Int = (x + y) * multiplier
println(addThenMultiply(1, 2)(3)) // 9
```

无参方法:

```scala
def name: String = System.getProperty("user.name")
//也可以写成 def name(): String = System.getProperty("user.name")

println("Hello, " + name + "!")
//也可以写成println("Hello, " + name() + "!")

```

方法体是多行语句的表达式：

```scala
def getSquareString(input: Double): String = {  

val square = input * input  

square.toString}
```

带有默认值的方法:

```scala
    def funcadd(str:String="hello scala!")
    {
      println(str);
    }
```

默认参数，可以有多个，对位置也不做要求

```scala
def method1(a:Int=1,b:Int,c:Int=3) = println("a="+a+"b="+b+"c="+c)
//调用
method1(b=2) //不能method1(2)
//或者
method1(1,2) //method1(a=1,b=2)
//或者
method1(1,2,3) //method1(c=1,b=2,a=3)
```

可变参数或不定长参数

**注意1：（可变参数一定是参数列表的最后一个参数）**

**注意2：函数内部，重复参数的类型是声明参数类型的数组**，但是如果你给一个可变参数的方法传一个数组，是会报编译错误：type mismatch，可以使用数组名:_*的方式传参。

```Scala
  def add(a:Int*)
    {
      for(i<-a)
      {
        println(i);
      }
    }

调用：
add(1,2,3,4,5)
或者：
var arr = Array(1,2,3,4,5,8)
add(arr:_*)
```

注意：

1. 方法的返回值类型可以不写，编译器可以自动推断出来，但是对于递归函数，必须指定返回类型
2. 方法的返回值默认是方法体中最后一行表达式 的值，当然也可以用return来执行返回值，但不推荐这么做。
3. 若使用`return`来制定函数的返回值，scala的类型推断将会失效，要显式指定返回值类型。
4. 方法也可以没有返回值（返回值是Unit）

#### 3.6.2. 定义函数

给方法传递一个函数类型的参数:

```scala
def foo(f: Int => String) = ...

def bar(f: (Boolean, Double) => List[String]) = ...
```

函数可以看做是带有参数的表达式。

函数定义的方式：

1，函数的定义方式：

```scala
val f1 = ((a: Int, b: Int) => a + b)

val f2 = (a: Int, b: Int) => a + b

val f3 = (_: Int) + (_: Int)

val f4: (Int, Int) => Int = (_ + _)
```

2，函数的定义方式：

```scala
val f1:((Int,Int)=>Int)={(x,y)=>x+y}
val f2:(Int,Int)=>Int =(x,y)=>x+y
```

3，函数的定义方式：

```scala
val f1 = new Function2[Int, Int, Int] { 
    def apply(x: Int, y: Int): Int = if (x < y) y else x 
} 
```

匿名函数：

```scala
(x: Int) => x + 1
```

多参数函数：

![](res15.png) 

无参函数：

```
val getTheAnswer = () => 42
println(getTheAnswer()) // 42
```

#### 3.6.3. 方法和函数的区别

- 方法和函数的定义语法不同
- 方法一般定义在某个类、特质、或者object中
- 方法可以共享使用所在类内的属性


在函数式编程语言中，函数是“头等公民”，可以调用它，也可以传递它，存放在变量中，或者作为参数传递给另一个函数。

案例：首先定义一个方法，再定义一个函数，然后将函数传递到方法里面

![](res16.png)

#### 3.6.4. 将方法转换成函数

把方法作为参数传给另一个方法或者函数的时候，方法被转化成函数

使用神奇的下划线_

![](res17.png) 

## 4. 集合

集合是一种用来存储各种对象和数据的容器

Scala 集合分为可变的和不可变的集合。

可变集合可以在适当的地方被更新或扩展。这意味着你可以修改，添加，移除一个集合的元素。

而不可变集合类，相比之下，永远不会改变。不过，你仍然可以模拟添加，移除或更新操作。但是这些操作将在每一种情况下都返回一个新的集合，同时使原来的集合不发生改变。

![](collection1.png)

![](collection2.png)

### 4.1. 数组(Array)

#### 4.1.1. 定长数组

创建一个定长数组的方式

![](array01.png)

使用Array定义一个长度不变的数组

```scala
object ArrayDemo {
  def main(args: Array[String]){
    //初始化一个长度为8的定长数组，其所有元素均为0
    val arr1 = new Array[Int](8)
    //直接打印定长数组，内容为数组的hashcode值
    println(arr1)
    //将数组转换成数组缓冲，就可以看到原数组中的内容了
    //toBuffer会将数组转换长数组缓冲
    println(arr1.toBuffer)

    //注意：如果不使用new获取数组，相当于调用了数组的apply方法，直接为数组赋值
    //初始化一个长度为1，值为10的定长数组
    val arr2 = Array[Int](10)
    //输出数组元素值
    println(arr2.toBuffer)

    //定义一个长度为3的定长数组
    val arr3 = Array("hadoop", "storm", "spark")
    //使用()来访问元素
    println(arr3(2))

    //包含10个整数的数组，初始化值为0 
    val nums = new Array[Int](10)
    //遍历数组
    for(i <- 0 until nums.length)
      print(s"$i:${nums(i)} ")
      println()

    //包含10个字符串的数组，初始化值为null
    val strs0 = new Array[String](10)
    for(i <- 0 until strs0.length)
      print(s"$i:${strs0(i)} ")
      println()

    //赋初值的字符串数组
    val strs1 = Array("hello" ,"world")
    for(i <- 0 until strs1.length)
      print(s"$i:${strs1(i)} ")
      println()

    //访问并修改元素值
    strs1(0) = "byebye"
    for(i <- 0 until strs1.length)
      print(s"$i:${strs1(i)} ")
      println()

  }
}


```

result

![](res3.png)

#### 4.1.2. 变长数组

定义变长数组的方式:

![](arrayBuffer01.png)

使用 ArrayBuffer定义长度按需变化的数组。

```scala
import scala.collection.mutable.ArrayBuffer

object VarArrayDemo {
  def main(args: Array[String]){
    //定义一个空的可变长Int型数组
    val nums =  ArrayBuffer[Int]()

    //在尾端添加元素
    nums += 1

    //在尾端添加多个元素
    nums += (2,3,4,5)

    //使用++=在尾端添加任何集合
    nums ++= Array(6,7,8)

   //这些操作符，有相应的 -= ，--=可以做数组的删减，用法同+=，++=
      
   //使用append追加一个或者多个元素
    nums.append(1)
    nums.append(2,3)
      
   //在下标2之前插入元素
    nums.insert(2,20)
    nums.insert(2,30,30)    

    //移除最后2元素
    nums.trimEnd(2)
    //移除最开始的一个或者多个元素
    nums.trimStart(1)
   
    //从下标2出移除一个或者多个元素
    nums.remove(2)
    nums.remove(2,2)
      
      
   //使用增强for循环进行数组遍历   
    for(elem <- nums)
      println(elem)
      
    //基于下标访问使用增强for循环进行数组遍历
    for(i <- 0 until nums.length)
      println(nums(i))

  }
}


```

执行结果：

![](res4.png)



#### 4.1.3. 遍历数组

1.增强for循环,参见变长数组的代码

2.好用的until会生成脚标，0 until 10 包含0不包含10 参见定长数组部分代码4.1.4. 数组转换

#### 4.1.4. 数组转换

yield关键字将原始的数组进行转换会产生一个新的数组，原始的数组不变

```scala
bject ArrayTransfer {

  def main(args: Array[String]): Unit = {

    //使用for推导式生成一个新的数组
    val a = Array(1, 2, 3, 4, 5, 6, 7, 8, 9)
    val res1 = for(elem <- a) yield 2*elem
    for(elem <- res1)
      print(elem+" ")
    println()

    //对原数组元素过滤后生成一个新的数组
    //将偶数取出乘以10后再生成一个新的数组
    val res2 = for(elem <- a if elem%2 == 0)yield 2*elem
    for(elem <- res2)
      print(elem+" ")
    println()

    //使用filter和map转换出新的数组
    val res3 = a.filter(_ % 2 == 0).map(2 * _)
    for(elem <- res3)
      print(elem+" ")
    println()
  }
```

执行结果：

![](res5.png)

#### 4.1.5. 数组常用算法

在Scala中，数组上的某些方法对数组进行相应的操作非常方便！

```scala
object ArrayAlgorithm {
  def main(args: Array[String]): Unit = {

    val a = Array(9, 1, 2, 5, 3, 7, 8, 4)

    //求和
    val res1 = a.sum
    println(res1)

    //求最大值
    val res2 = a.max
    println(res2)

    //排序
    val res3 = a.sorted
    // val res4 = a.sortWith(_>_)指定排序方式
    for(elem <- res3)
      print(elem + " ")
  }
}
```

执行结果：

![](res6.png)



### 4.2. 映射（map）

在Scala中，把哈希表这种数据结构叫做映射。

#### 4.2.1. 构建映射  

在Scala中，有两种Map，一个是immutable包下的Map，该Map中的内容不可变；另一个是mutable包下的Map，该Map中的内容可变。

构建一个不可变的map

![](res7.png)

使用元组方式构建

![](res14.png)

构建一个可变的map

![](res8.png)

#### 4.2.2. 获取和修改映射中的值

根据键获取map中对应的值，可以有以下三种方法，尤其推荐使用getOrElse方法。

![](res9.png)

修改可变map信息，遍历访问map

```scala
object MappingDemo {
  def main(args: Array[String]): Unit = {
    //定义构建一个可变的map
    val scores = scala.collection.mutable.Map ("zhangsan" -> 90, "lisi" -> 80, "wangwu" -> 0)
    //val scores2 = scala.collection.mutable.Map ("moumou"->50)   
    //修改map中对应键的值
    scores("wangwu") = 100

    //添加新的键值到map中
    scores("zhaoliu") = 50 //类似 scores.update("zhangsan",50)
    scores += ("sunqi" -> 60, "qianba" -> 99)
    //scores ++ =scores2

    //移除某个键值对
    scores -= "zhangsan" //类似 scores.remove("zhangsan")
    //scores -- =scores2 不好用？？？

    //获取键的集合并遍历
    //意义不大？如何通过建取到值
    val res = scores.keySet
    for(elem <- res)
      print(elem + "  ")
    println()

    //遍历map
    for ((k,v) <- scores)
      print(k+":"+v+"  ")
  }
```

执行结果

![](res10.png)

#### 4.2.3. HashMap

可变map

```scala
import scala.collection.mutable

object MutMapDemo extends App{
  val map1 = new mutable.HashMap[String, Int]()
  //向map中添加数据
  map1("spark") = 1
  map1 += (("hadoop", 2))
  map1.put("storm", 3)
  println(map1)

  //从map中移除元素
  map1 -= "spark"
  map1.remove("hadoop")
  println(map1)
}
```

### 4.3. 元组(Tuple)

映射是K/V对偶的集合，对偶是元组的最简单形式，元组可以装着多个不同类型的值，是不同类型的值的聚集。

#### 4.3.1. 创建访问元组

创建元组：使用小括号将多个元素括起来，元素之间用逗号分隔，元素的类型和个数任意，

访问组元：使用_1， _2， _3等访问组元。

第二种方式定义的元组也可以通过a,b,c去访问组元。

![](res13.png)

另一种定义方式:

```scala
val t = new Tuple3(1, 3.14, "Fred")
```

元组的实际类型取决于它的元素的类型，比如 (99, "runoob") 是 Tuple2[Int, String]。 ('u', 'r', "the", 1, 4, "me") 为 Tuple6[Char, Char, String, Int, Int, String]。

目前 Scala 支持的元组最大长度为 22。对于更大长度你可以使用集合，或者扩展元组。

**元组元素迭代遍历**

```
object Test {
   def main(args: Array[String]) {
      val t = (4,3,2,1)
      t.productIterator.foreach{ i =>println("Value = " + i )}
   }
}
```

#### 4.3.2. 拉链操作

 使用zip方法把元组的多个值绑在一起，以便后续处理

![](res12.png) 

注意：如果两个数组的元素个数不一致，拉链操作后生成的数组的长度为较小的那个数组的元素个数

### 4.4. 列表(List)

不可变的序列 import scala.collection.immutable._

在Scala中列表要么为空（Nil表示空列表）要么是一个head元素加上一个tail列表。

9 :: List(5, 2)  :: 操作符是将给定的头和尾创建一个新的列表

注意：:: 操作符是右结合的，如9 :: 5 :: 2 :: Nil相当于 9 :: (5 :: (2 :: Nil))

不可变列表

```scala
object ImmutListDemo {

    def main(args: Array[String]) {
      //创建一个不可变的集合
      val lst1 = List(1,2,3)
      //将0插入到lst1的前面生成一个新的List
      val lst2 = 0 :: lst1
      val lst3 = lst1.::(0)
      val lst4 = 0 +: lst1
      val lst5 = lst1.+:(0)

      //将一个元素添加到lst1的后面产生一个新的集合
      val lst6 = lst1 :+ 3

      val lst0 = List(4,5,6)
      //将2个list合并成一个新的List
      val lst7 = lst1 ++ lst0
      //将lst1插入到lst0前面生成一个新的集合
      val lst8 = lst1 ++: lst0

      //将lst0插入到lst1前面生成一个新的集合
      val lst9 = lst1.:::(lst0)

      println(lst9)
    }

}

```

可变

```scala
import scala.collection.mutable.ListBuffer

object MutListDemo extends App{
  //构建一个可变列表，初始有3个元素1,2,3
  val lst0 = ListBuffer[Int](1,2,3)
  //创建一个空的可变列表
  val lst1 = new ListBuffer[Int]
  //向lst1中追加元素，注意：没有生成新的集合
  lst1 += 4
  lst1.append(5)

  //将lst1中的元素最近到lst0中， 注意：没有生成新的集合
  lst0 ++= lst1

  //将lst0和lst1合并成一个新的ListBuffer 注意：生成了一个集合
  val lst2= lst0 ++ lst1

  //将元素追加到lst0的后面生成一个新的集合
  val lst3 = lst0 :+ 5
}
```

### 4.5. set

不可变

```scala
import scala.collection.immutable.HashSet

object ImmutSetDemo extends App{
  val set1 = new HashSet[Int]()
  //将元素和set1合并生成一个新的set，原有set不变
  val set2 = set1 + 4
  //set中元素不能重复
  val set3 = set1 ++ Set(5, 6, 7)
  val set0 = Set(1,3,4) ++ set3
  //set中的元素是随机无序的
  print(set0)
  println(set0.getClass)
}
```

可变

```scala
import scala.collection.mutable

object MutSetDemo extends App{
  //创建一个可变的HashSet
  val set1 = new mutable.HashSet[Int]()
  //向HashSet中添加元素
  set1 += 2
  //add等价于+=
  set1.add(4)
  set1 ++= Set(1,3,5)
  println(set1)
  //删除一个元素
  set1 -= 5
  set1.remove(2)
  println(set1)
}
```

### 4.6 集合的重要函数

#### 4.6.1sum/max/min/count

 在序列中查找最大或最小值是一个极常见的需求，如下：

~~~scala
val numbers = Seq(11, 2, 5, 1, 6, 3, 9)   
numbers.max //11   
numbers.min //1  

~~~

更高级的例子，其中包含一个书的序列

~~~scala
case class Book(title: String, pages: Int)   
val books = Seq( Book("Future of Scala developers", 85),   
                  Book("Parallel algorithms", 240),   
                  Book("Object Oriented Programming", 130),   
                  Book("Mobile Development", 495) )   
//Book(Mobile Development,495)   
 books.maxBy(book => book.pages)   
//Book(Future of Scala developers,85)   
 books.minBy(book => book.pages)  
~~~

 如上所示，minBy & maxBy 方法解决了复杂数据的问题。你只需选择决定数据最大或最小的属性。

####  4.6.2 过滤 

过滤一个数字 List，只获取奇数的元素。

~~~
val numbers = Seq(1,2,3,4,5,6,7,8,9,10) numbers.filter(n => n % 2 == 0)  
~~~

~~~scala
val books = Seq( Book("Future of Scala developers", 85),   
                Book("Parallel algorithms", 240),   
                 Book("Object Oriented Programming", 130),   
                 Book("Mobile Development", 495) )   
books.filter(book => book.pages >= 120)  

~~~

#### 4.6.3 Flatten

~~~
val abcd = Seq('a', 'b', 'c', 'd')   
val efgj = Seq('e', 'f', 'g', 'h')   
val ijkl = Seq('i', 'j', 'k', 'l')   
val mnop = Seq('m', 'n', 'o', 'p')   
val qrst = Seq('q', 'r', 's', 't')   
val uvwx = Seq('u', 'v', 'w', 'x')   
val yz = Seq('y', 'z')   
val alphabet = Seq(abcd, efgj, ijkl, mnop, qrst, uvwx, yz)   
 //   
 // List(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t,  
 //      u, v, w, x, y, z)   
 alphabet.flatten  

~~~

 当有一个集合的集合，然后你想对这些集合的所有元素进行操作时，就会用到 flatten。

####  4.6.4集合之间的操作

差集、交集和并集

~~~scala
val num1 = Seq(1, 2, 3, 4, 5, 6)   
val num2 = Seq(4, 5, 6, 7, 8, 9)   
//List(1, 2, 3)   
num1.diff(num2)   
//List(4, 5, 6)   
num1.intersect(num2)   
//List(1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9)   
num1.union(num2)  
~~~

 上述示例中的 union 保留了重复的元素。如果我们不需要重复怎么办？这时可以使用 distinct 函数

 ~~~
//List(1, 2, 3, 4, 5, 6, 7, 8, 9)   
num1.union(num2).distinct  
 ~~~

 下面是上述功能的图示：

 ![img](https://img-blog.csdn.net/20170106090126893?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvaGo3amF5/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/Center)

####  4.6.5 map（映射）列表元素 

 map 是 Scala 集合最常用的一个函数。它的功能十分强大：

~~~scala
val numbers = Seq(1,2,3,4,5,6)   
//List(2, 4, 6, 8, 10, 12)   
numbers.map(n => n * 2)   
val chars = Seq('a', 'b', 'c', 'd')   
//List(A, B, C, D)   
chars.map(ch => ch.toUpper)  
~~~

 map 函数的逻辑是遍历集合中的元素并对每个元素调用函数。

#### 4.6.6 flatMap 

flatMap 是由下列这两个函数组成的：

 map & flatten

例子：

~~~scala
val abcd = Seq('a', 'b', 'c', 'd')   
//List(A, a, B, b, C, c, D, d)   
abcd.flatMap(ch => List(ch.toUpper, ch))
~~~

####  4.6.7 对整个集合进行条件检查 

~~~
1. val numbers = Seq(3, 7, 2, 9, 6, 5, 1, 4, 2)   
2. //ture numbers.forall(n => n < 10)   
3. //false numbers.forall(n => n > 5) 
~~~

 而 forall 函数就是为处理这类需求而创建的。

####  4.6.8 对集合进行分组 

 比如把某个集合拆分成偶数集和奇数集，partition 函数可以帮我们做到这一点：

~~~
 val numbers = Seq(3, 7, 2, 9, 6, 5, 1, 4, 2)   
 //(List(2, 6, 4, 2), List(3, 7, 9, 5, 1))   
 numbers.partition(n => n % 2 == 0)  

~~~

#### 4.6.9 Fold

 另一个流行的操作是 fold，通常可以考虑 foldLeft 和 foldRight。他们是从不同的方面做同样的工作： 

~~~scala
 val numbers = Seq(1, 2, 3, 4, 5)   
//15 numbers.foldLeft(0)((res, n) => res + n)  
val words = Seq("apple", "dog", "table")   
//13 words.foldLeft(0)((resultLength, word) => resultLength + word.length)  
~~~

**foldLeft, reduceRight, and foldRight**

​    方法foldLeft与reduceLeft工作方法很象，但是它让你指定一个值作为第一个元素。

```scala
scala> val a = Array(1, 2, 3)
a: Array[Int] = Array(1, 2, 3)

scala> a.reduceLeft(_+_)
res6: Int = 6

scala> a.foldLeft(100)(_+_)
res7: Int = 106

scala> a.foldLeft(200)(_+_)
res8: Int = 206
```

### 5.1. 类

#### 5.1.1. 类的定义

Scala 访问修饰符基本和Java的一样，分别有：private，protected，public。

如果没有指定访问修饰符符，默认情况下，Scala 对象的访问级别都是 public。

**私有(Private)成员**

用 private 关键字修饰，带有此标记的成员仅在包含了成员定义的类或对象内部可见，同样的规则还适用内部类。

```scala
class Outer{
    class Inner{
    private def f(){println("f")}
    class InnerMost{
        f() // 正确
        }
    }
    (new Inner).f() //错误
}
```

 (new Inner).f( ) 访问不合法是因为 **f** 在 Inner 中被声明为 private，而访问不在类 Inner 之内。

但在 InnerMost 里访问 **f** 就没有问题的，因为这个访问包含在 Inner 类之内。

Java中允许这两种访问，因为它允许外部类访问内部类的私有成员。 

**保护(Protected)成员**

 在 scala 中，对保护（Protected）成员的访问比 java 更严格一些。因为它只允许保护成员在定义了该成员的的类的子类中被访问。而在java中，用protected关键字修饰的成员，除了定义了该成员的类的子类可以访问，同一个包里的其他类也可以进行访问。 

```scala
package p{
class Super{
    protected def f() {println("f")}
    }
    class Sub extends Super{
        f()
    }
    class Other{
        (new Super).f() //错误
    }
}
```

类的定义示例：

```scala
//定义Point类，构造器带有两个参数
class Point(var x: Int, var y: Int) {

    //无返回值的类方法
  def move(dx: Int, dy: Int): Unit = {
    x = x + dx
    y = y + dy
  }

    //没有参数但是返回值为String类型的重写方法
  override def toString: String =
    s"($x, $y)"
}

//创建类的实例
val point1 = new Point(2, 3)
point1.x  // 2
println(point1)  // prints (2, 3)
```

构造器可以带有默认值：

```scala
class Point(var x: Int = 0, var y: Int = 0){
...
}
val origin = new Point  // x, y都取默认值0
val point1 = new Point(1)//x=1,y=0
println(point1.x)  // prints 1
```

私有成员变量以及重新定义的Getter/Setter方法：

```scala
 private var _x = 0
  private var _y = 0
  private val bound = 100

  def x = _x
  def x_= (newValue: Int): Unit = {
    if (newValue < bound) _x = newValue else printWarning
  }

  def y = _y
  def y_= (newValue: Int): Unit = {
    if (newValue < bound) _y = newValue else printWarning
  }

  private def printWarning = println("WARNING: Out of bounds")
}

val point1 = new Point
point1.x = 99
point1.y = 101 // prints the warning
```

类定义中的其他细节：

```scala
//在Scala中，类并不用声明为public。
//Scala源文件中可以包含多个类，所有这些类都具有公有可见性。
class Person {
  //用val修饰的变量是只读属性的，只带getter方法但没有setter方法
  //（相当与Java中用final修饰的变量）
  //字段必须初始化
  val id = "1234"

  //用var修饰的变量，默认同时有公开的getter方法和setter方法
  var age: Int = 18

  //类私有字段,有私有的getter方法和setter方法，只能在类的内部使用
  private var name: String = "王老五"

  //对象私有字段,访问权限更加严格的，Person类的方法只能访问到当前对象的字段
  private[this] val hobby = "旅游"
}
```

scala中，在实现属性时你有如下四个选择：

　　1. var foo: Scala自动合成一个getter和一个setter

　　2.  val foo: Scala自动合成一个getter

　　3. 由你来定义foo和foo_=方法

　　4. 由你来定义foo方法 

#### 5.1.2. 构造器

注意：

1.主构造器会执行类定义中的所有语句

2.主构造器如果有参数直接放置在类名之后

​      class ConstructorDemo ( val id: Int ) { … }

3.主构造器变成私有的，可以像这样放置private关键字：

　　class ConstructorDemo private ( val id: Int ) { … }

​    此时，用户必须通过辅助构造器来构造Person对象

```scala
class ConstructorDemo {

  private var var1 = ""

  private var var2 = 0

  //辅助构造器1
  def this(var1:String) {
    this()  //调用主构造器
    this.var1 = var1
  }

  //辅助构造器2
  def this(var1:String, var2:Int) {
    this(var1) //调用辅助构造器1
    this.var2 = var2
  }

}
```

### 5.2.特质（备选）

特质的定义除了使用关键字trait之外，与类定义无异。

特质用来在类之间进行接口或者属性的共享。类和对象都可以继承特质，特质不能被实例化，因此也没有参数。

一旦特质被定义了，就可以使用extends或者with在类中混入特质。

#### 5.2.1 作为接口使用的特质

特质的定义：

~~~scala
trait Logger{
    //这是一个抽象方法，特质中未被实现的方法默认是抽象的，不需要abstract关键字修饰
     def log(msg:String)
}
~~~

子类对特质的实现：

~~~scala
class ConsoleLogger extends Logger{
    //重写抽象方法，不需要override
    def log(msg:String){println(msg)}
}
~~~

#### 5.2.2 带有具体实现的特质

~~~scala
trait ConsoleLogger{
    //注意与Java中接口的不同
      def log(msg:String){println(msg)}
}
~~~

特质的使用

```scala
class SavingAccount extends Account with ConsoleLogger{
    def withdraw(amount:Double){
        if(amount >balance) log("Insufficent funds")
        else balance -= amount
    }
}
```

#### 5.2.3 带有特质的对象

scala自带有Logged特质，但是没有实现

~~~scala
trait Logged{
    def log(msg:String){}
}
~~~

如果在类定义中使用了该特质

~~~scala
//该类中，其中的日志信息不会被记录
class SavingAccount extends Account with Logged{
    def withdraw(amount:Double){
        if(amount >balance) log("Insufficent funds")
        else balance -= amount
    }
}
~~~

标准的ConsoleLogger扩展自Logger

~~~scala
class ConsoleLogger extends Logger{
    //重写抽象方法，不需要override
    def log(msg:String){println(msg)}
}
~~~

可以在创建对象的时候，加入该特质：

~~~scala
val acct1=new SavingAccount with ConsoleLogger
~~~

这样，创建同一类对象，却可以加入不同的特质

~~~scala
val acct2=new SavingAccount with FileLogger
~~~

####5.2.4 多个叠加的特质

可以为类或者对象添加多个互相调用的特质，特质的执行顺序，取决于特质被添加的顺序

~~~scala
trait Logged{
  def log(msg:String)
}
trait ConsoleLogger extends Logged{
  //重写抽象方法，不需要override
  def log(msg: String) ={println(msg)}
}
//给log加上时间戳
trait TimestampLogger extends ConsoleLogger {
  override def log(msg: String) {
    super.log(s"${java.time.Instant.now()} $msg")
  }
}
//截断过于冗长的日志信息
trait ShortLogger extends ConsoleLogger{
    val maxLength = 15
    override def log(msg: String) {
      super.log(
        if(msg.length <=maxLength)msg
        else
          s"${msg.substring(0,maxLength-3)}...")
    }
  }
//定义超类
class Account {
  protected var balance:Double = 0
}
class SavingAccount extends Account with ConsoleLogger{
  def withdraw(amount:Double){
    if(amount >balance) log("Insufficent funds")
    else balance = balance - amount
  }
}

object test{
  def main(args: Array[String]): Unit = {
    val acct1 = new SavingAccount with ConsoleLogger with TimestampLogger with ShortLogger
    val acct2 = new SavingAccount with ConsoleLogger with ShortLogger with TimestampLogger
    acct1.withdraw(100.0)
    acct2.withdraw(100.0)

  }
}

//res:
//ShortLogger的log方法先被执行，然后它的super.log调用的是TimestampLogger 的log方法，最后调用ConsoleLogger 的方法将信息打印出来
2018-06-15T16:50:28.448Z Insufficent ...
//先是TimestampLogger 的log方法被执行，然后它的super.log调用的是ShortLogger的log方法，最后调用ConsoleLogger 的方法将信息打印出来
2018-06-15T1...
~~~

####5.2.5 使用特质统一编程

```scala
import scala.collection.mutable.ArrayBuffer

trait Pet {
  val name: String
}

class Cat(val name: String) extends Pet
class Dog(val name: String) extends Pet

val dog = new Dog("Harry")
val cat = new Cat("Sally")

val animals = ArrayBuffer.empty[Pet]
animals.append(dog)
animals.append(cat)
animals.foreach(pet => println(pet.name))  // Prints Harry Sally
```

Mixins用于进行类组合的特质：

```scala
 abstract class A {
     val message: String
}
class B extends A {
  val message = "I'm an instance of class B"
}
//此处的特质C即为mixin
trait C extends A {
  def loudMessage = message.toUpperCase()
}
class D extends B with C

val d = new D
println(d.message)  // I'm an instance of class B
println(d.loudMessage)  // I'M AN INSTANCE OF CLASS B
```

#### 5.2.6 当做富接口使用的特质

~~~scala
//注意抽象方法和具体方法的结合
trait Logger { def log(msg: String)
  def info(msg: String) { log("INFO: " + msg) }
  def warn(msg: String) { log("WARN: " + msg) }
  def severe(msg: String) {log("SEVERE: " + msg)}
}
class Account {
  protected var balance:Double = 0
}
class SavingsAccount extends Account with Logger {
  def withdraw(amount: Double) {
    if (amount > balance) severe("Insufficient funds") else "you can do this" }
  override def log(msg: String) { println(msg) }
}

object test{
  def main(args: Array[String]): Unit = {
    val acc = new SavingsAccount
    acc.withdraw(100)
  }
}
//result
SEVERE: Insufficient funds
~~~

#### 5.2.7特质中的具体字段和抽象字段

特质中的字段有初始值则就是具体的，否则是抽象的。

```scala
trait ShortLogger extends Logged {
  val maxLength = 15   // 具体字段
}
```

那么继承该特质的子类是如何获得这个字段的呢。Scala是直接将该字段放入到继承该特制的子类中，而不是被继承。例如：

```scala
class SavingsAccount extends Account with ConsoleLogger with ShortLogger {
  var interest = 0.0
  def withdraw(amount: Double) {
    if (amount > balance) log("Insufficient funds")
    else ...
  }
}
```

特质中的抽象字段在具体的子类中必须被重写:

```scala
trait ShortLogger extends Logged {
  val maxLength: Int//抽象字段
  override def log(msg: String) {
    super.log( if (msg.length <= maxLength) msg else msg.substring(0, maxLength - 3)  + "...")
  }
}

class SavingsAccount extends Account with ConsoleLogger with ShortLogger {
  val maxLength = 20   // 不需要写override
}
```

#### 5.2.8 特质构造顺序

特质也是有构造器的，由字段的初始化和其他特质体中的语句构成：

```scala
trait FileLogger extends Logger {
  val out = new PrintWriter("app.log")     // 构造器的一部分
  out.println("# " + new Date().toString)  // 也是构造器的一部分

  def log(msg: String) { out.println(msg); out.flush() }
}
```

这些语句在任何混入了该特质的对象在构造时都会被执行。
 **构造器的顺序：**

- 首先调用超类的构造器
- 特质构造器在超类构造器之后、类构造器之前执行
- 特质由左到右被构造
- 每个特质中，父特质先被构造
- 如果多个特质共有一个父特质，那么那个父特质已经被构造，则不会被再次构造
- 所有特质构造完毕后，子类被构造。
   例如：

```
class SavingsAccount extends Account with FileLogger with ShortLogger
```

构造器执行顺序：

1Account （超类）

2 Logger (第一个特质的父特质)

3 FileLogger

4 ShortLogger

5 SavingsAccount

####5.2.9 初始化特质中的字段

**特质不能有构造器参数，每个特质都有一个无参构造器。**这也是特质和类的差别。
 例如： 我们要在构造的时候指定log的输出文件：

```scala
trait FileLogger extends Logger {
  val filename: String                            // 构造器一部分
  val out = new PrintWriter(filename)     // 构造器的一部分
  def log(msg: String) { out.println(msg); out.flush() }
}

val acct = new SavingsAccount extends Account with FileLogger("myapp.log")  //error，特质没有带参数的构造器

// 你也许会想到和前面重写maxLength一样，在这里重写filename:
val acct = new SavingsAccount with FileLogger {
  val filename = "myapp.log"   // 这样是行不通的
}
```

FileLogger的构造器先于子类构造器执行。这里的子类其实是一个扩展自SavingsAccount 并混入了FileLogger特质的匿名类。而filename的初始化发生在这个匿名类中，而FileLogger的构造器会先执行，因此new PrintWriter(filename)语句会抛出一个异常。
 解决方法是要么使用提前定义或者使用懒值：

```scala
val acct = new {
  val filename = "myapp.log"
} with SavingsAccount with FileLogger

// 对于类同样：
class SavingsAccount extends {
  val filename = "myapp.log"
} with Account with FileLogger { 
  ...   // SavingsAccount 的实现
}

// 或使用lazy
trait FileLogger extends Logger {
  val filename: String                            // 构造器一部分
  lazy val out = new PrintWriter(filename)     // 构造器的一部分
  def log(msg: String) { out.println(msg); out.flush() }
}
```

 #### 5.2.10 扩展类的特质

特质也可以扩展类，这个类将会自动成为所有混入该特质的超类

```
trait LoggedException extends Exception with Logged {
  def log() { log(getMessage()) }
}
```

log方法调用了从Exception超类继承下来的getMessage 方法。那么混入该特质的类：

```
class UnhappyException extends LoggedException {
  override def getMessage() = "arggh!"
}
```

### 5.3.抽象类（备选）

####5.3.1抽象类的定义

定义一个抽象类：

如果某个类至少存在一个抽象方法或一个抽象字段，则该类必须声明为abstract。

```scala
abstract class Person{
//没有初始值，抽象字段
var name:String
//没有方法体，是抽象方法
def id: Int

}

class Employ extends Person{
var name:String="Fred"
//实现，不需要overide关键字
def id = name.hashCode

}
```

####5.3.2抽象类的应用

定义带有抽象类型成员的特质：

```scala
trait Buffer {
  type T
  val element: T
}
```

定义一个抽象类,增加类型的上边界

```scala
abstract class SeqBuffer extends Buffer {
  type U
  //
  type T <: Seq[U]
  def length = element.length
}
```

```scala
abstract class IntSeqBuffer extends SeqBuffer {
  type U = Int
}

```

```scala
abstract class IntSeqBuffer extends SeqBuffer {
  type U = Int
}

//使用匿名类将 type T 设置为 List[Int]
def newIntSeqBuf(elem1: Int, elem2: Int): IntSeqBuffer =
  new IntSeqBuffer {
       type T = List[U]
       val element = List(elem1, elem2)
     }
val buf = newIntSeqBuf(7, 8)
println("length = " + buf.length)
println("content = " + buf.element)
```

### 5.2. 对象

#### 5.2.1. 单例对象

在Scala中没有静态方法和静态字段，但是可以使用object这个语法结构来达到同样的目的

1.scala类似于Java中的工具类，可以用来存放工具函数和常量

2.高效共享单个不可变的实例

3.单例模式

单例对象虽然类似于Java中的工具类，但它不是，还是一个对象，可以把单例对象名看做一个贴在对象上的标签。

```scala
package logging
//使用关键字object定义单例对象
object Logger {
  def info(message: String): Unit = println(s"INFO: $message")
}
```

单例对象的使用

```scala
//导入单例对象信息，使之在当前类可见
import logging.Logger.info

class Project(name: String, daysToComplete: Int)

class Test {
  val project1 = new Project("TPS Reports", 1)
  val project2 = new Project("Website redesign", 5)
    //调用单例对象中定义的方法
  info("Created projects")  // Prints "INFO: Created projects"
}
```

类和单例对象的区别是，单例对象不能带参数，单例对象不能用new关键字实例化，所以没有机会传递给它实例化的参数。

单例对象在第一次访问的时候才会初始化。

当单例对象与某个类同名时，它被称为类的伴生对象，类和伴生对象必须定义在一个源文件里，类称为该单例对象的伴生类，类和他的伴生对象可以互相访问其私有成员。

不与伴生类共享名称的单例对象被称为独立对象，可以作为相关功能的工具类，或者scala应用程序的入口点。

#### 5.2.2. 伴生对象

在Scala的类中，与类名相同并且用object修饰的对象叫做伴生对象，类和伴生对象之间可以相互访问私有的方法和属性，他们必须存在同一个源文件中

```scala
class AccountInfo {
//类的伴生对象的功能特性并不在类的作用域
//所以不能直接用newUniqueNumber()调用伴生对象的方法
var id = AccountInfo.newUniqueNumber()
}

object  AccountInfo {
  private var lastNumber = 0
  private def newUniqueNumber() = {
    lastNumber += 1; lastNumber
  }

  def main(args: Array[String]) {
  //相当于Java中的静态方法调用
    println(AccountInfo.newUniqueNumber())
  }

}
```

#### 5.2.3. apply方法

通常我们会在类的伴生对象中定义apply方法，当遇到类名(参数1,...参数n)时apply方法会被调用

```scala
class AccountInfo {

}

object  AccountInfo {
  private var lastNumber = 0
  private def apply(arg :Int) = {
    lastNumber = arg*2 + 1; lastNumber
  }

  def main(args: Array[String]) {
    println(AccountInfo(1))
  }

}
```

#### 5.2.4. 应用程序对象

Scala程序都必须从一个对象的main方法开始，可以通过扩展App特质，不写main方法。

```scala
object Hello extends  App{
  println("Hello World")
}

```

同

```scala
object Hello {

  def main(args: Array[String]): Unit = {
    println("Hello World")
  }

}
```

#### 5.2.5.提取器

带有unapply方法的对象，经常用在模式匹配或者偏函数中。

```scala
import scala.util.Random

object CustomerID {

  def apply(name: String) = s"$name--${Random.nextLong}"

  def unapply(customerID: String): Option[String] = {
    val name = customerID.split("--").head
    if (name.nonEmpty) Some(name) else None
  }
}
//调用apply方法创建一个对象，等价于CustomerID.apply("Sukyoung")
val customer1ID = CustomerID("Sukyoung")  // Sukyoung--23098234908
customer1ID match {
    //调用unapply方法，提取name信息
  case CustomerID(name) => println(name)  // prints Sukyoung
  case _ => println("Could not extract a CustomerID")
}
```

### 5.3 继承

#### 5.3.1. 扩展类

在Scala中扩展类的方式和Java一样都是使用extends关键字

可以把类声明为final，使之不能扩张

也可以把单个方法或者字段声明为final，以确保它不能被重写，注意和Java的不同，Java中final修饰的字段意味着不可变。

#### 5.3.2. 重写方法

在Scala中重写一个非抽象的方法必须使用override修饰符

在子类中调用超类的方法，使用super，和Java一致。

#### 5.3.3.protected修饰的字段和方法

被protected修饰的字段或者方法，可以被其子类访问；

与Java不同的是，protected修饰的成员对于类所属的包是不可见的；

protected[this]，访问权限仅限当前的对象

可以使用包修饰符改变protected修饰的成员的可见性

#### 5.3.3. 类型检查和转换

|                              | **Scala**           | **Java**         |
| ---------------------------- | ------------------- | ---------------- |
| 测试某个对象是否属于给定的类 | obj.isInstanceOf[C] | obj instanceof C |
| 强制类型转换                 | obj.asInstanceOf[C] | (C)obj           |
| 获取对象的类信息             | classOf[C]          | C.class          |

#### 5.3.4. 超类的构造

下面代码定义了一个子类和一个调用超类构造器的主构造器

```
class Employ(name: String, age: Int, val Salary:Double) extends Person (name,age)
```

下面的代码展示类的继承，以及接口的实现等

```scala
object ClassDemo {
    def main(args: Array[String]) {
      val h = new Human
      println(h.byScala())
    }
  }
  //相当于Java的接口
  trait Coding{
    def byJava(flag : Boolean): Unit ={
      if(flag)
      {
        println("I can code by Java")
      }
      else{
          println("I can't code by Java")
      }
    }
    //未被实现的方法默认为抽象方法
    def byScala(): String
  }

  //抽象类
  abstract class Animal {
    def run(): Int
    val name: String
  }

  class Human extends Animal with Coding{

    val name = "abc"

    //打印几次"ABC"?
    val t1,t2,(a, b, c) = {
      println("ABC")
      (1,2,3)
    }

    println(a)
    println(t1._1)

    //在Scala中重写一个非抽象方法必须用override修饰
    override def byJava(flag: Boolean): Unit = {
      println("Coding by Java and Scala")
    }

    def byScala(): String={
      "coding by Scala"
    }
    //在子类中重写超类的抽象方法时，不需要使用override关键字，写了也可以
    def run(): Int = {
      1
    }

}

```

## 6. 模式匹配和样例类

### 6.1.样例类

在Scala中样例类是一中特殊的类，样例类是不可变的，

可以通过值进行比较，可用于模式匹配。

定义一个样例类：

1. 构造器中每一个参数都是val,除非显示地声明为var  
2. 伴生对象提供apply ，让你不使用new关键字就能构造出相应的对象

```scala
case class Point(x: Int, y: Int)
```

创建样例类对象：

```scala
val point = Point(1, 2)
val anotherPoint = Point(1, 2)
val yetAnotherPoint = Point(2, 2)
//访问对象值
point.x
point.x =1 //不可以
```

通过值对样例类对象进行比较：

```scala
if (point == anotherPoint) {
  println(point + " and " + anotherPoint + " are the same.")
} else {
  println(point + " and " + anotherPoint + " are different.")
}
// Point(1,2) 和 Point(1,2)一样的.

if (point == yetAnotherPoint) {
  println(point + " and " + yetAnotherPoint + " are the same.")
} else {
  println(point + " and " + yetAnotherPoint + " are different.")
}
// Point(1,2)和Point(2,2)是不同的.
```

样例类的拷贝

You can create a (shallow) copy of an instance of a case class simply by using the `copy` method. You can optionally change the constructor arguments. 

~~~scala
case class Message(sender: String, recipient: String, body: String)
val message4 = Message("julien@bretagne.fr", "travis@washington.us", "Me zo o komz gant ma amezeg")
val message5 = message4.copy(sender = message4.recipient, recipient = "claire@bourgogne.fr")
message5.sender  // travis@washington.us
message5.recipient // claire@bourgogne.fr
message5.body  // "Me zo o komz gant ma amezeg"
~~~

在模式匹配中使用样例类：

```scala
abstract class Amount
// 继承了普通类的两个样例类
case class Dollar(value: Double) extends Amount
case class Currency(value: Double, unit: String) extends Amount
case object Nothing extends Amount
object CaseClassDemo {

  def main(args: Array[String]): Unit = {
    val amt = new Dollar(10);
    patternMatch(amt)
  }
  def patternMatch(amt: Amount) {
    amt match {
      case Dollar(v) => println("$" + v)
      case Currency(_, u) => println("Oh noes, I got " + u)
      case Nothing => println("nothing") //样例对象没有()
    }
  }
}

```

声明样例类 ，以下几件事会自动发生：

1. 提供unapply方法，让模式匹配可以工作  
2. 生成toString equals hashCode copy 方法，除非显示给出这些方法的定义。

### 6.2.模式匹配

#### 6.1.1.更好的switch

Scala中类似Java的switch代码：

注意：

Scala的模式匹配只会匹配到一个分支，不需要使用break语句，因为它不会掉入到下一个分支。
 match是表达式，与if表达式一样，是有值的：

```scala
object PatternDemo {

  def main(args: Array[String]): Unit = {
    var sign = 0
    val ch: Char  = 'p'
    val valchar = 'p'
    var digit = 0

   //match 是表达式
    ch match {
      case '+' => sign = 1
      case '-' => sign = -1
      //使用|分割多个选项
      case '*' | 'x' => sign = 2
      //可以使用变量
      //如果case关键字后面跟着一个变量名，那么匹配的表达式会被赋值给那个变量。
      case valchar => sign = 3
      //case _ 类似Java中的default
      // 如果没有模式能匹配，会抛出MacthError
      //可以给模式添加守卫
      case _ if Character.isDigit(ch) => digit = Character.digit(ch, 10)
    }
    println("sign = "+ sign)
  }

}

```


#### 6.2.1常量模式(constant patterns) 包含常量变量和常量字面量
```scala
scala> val site = "alibaba.com"
scala> site match { case "alibaba.com" => println("ok") }
scala> val ALIBABA="alibaba.com"
//注意这里常量必须以大写字母开头
scala> def foo(s:String) { s match { case ALIBABA => println("ok") } } 
```

 常量模式和普通的 if 比较两个对象是否相等(equals) 没有区别，并没有感觉到什么威力

#### 6.2.2 变量模式(variable patterns)

 确切的说单纯的变量模式没有匹配判断的过程，只是把传入的对象给起了一个新的变量名。

```scala
scala> site match { case whateverName => println(whateverName) }
```

 上面把要匹配的 site对象用 whateverName 变量名代替，所以它总会匹配成功。不过这里有个约定，对于变量，要求必须是以小写字母开头，否则会把它对待成一个常量变量，比如上面的whateverName 如果写成**WhateverName**就会去找这个**WhateverName**的变量，如果找到则比较相等性，找不到则出错。

 变量模式通常不会单独使用，而是在多种模式组合时使用，比如

```scala
List(1,2) match{ case List(x,2) => println(x) }
```

 里面的x就是对匹配到的第一个元素用变量x标记。
#### 6.2.3 通配符模式(wildcard patterns)

 通配符用下划线表示：`"_"` ，可以理解成一个特殊的变量或占位符。
  单纯的通配符模式通常在模式匹配的最后一行出现，`case _ =>`  它可以匹配任何对象，用于处理所有其它匹配不成功的情况。
  通配符模式也常和其他模式组合使用：

```scala
scala> List(1,2,3) match{ case List(_,_,3) => println("ok") }
```

 上面的 `List(_,_,3)` 里用了2个通配符表示第一个和第二个元素，这2个元素可以是任意类型
  通配符通常用于代表所不关心的部分，它不像变量模式可以后续的逻辑中使用这个变量。

#### 6.2.4.样例类匹配

```scala
//定义样例类
abstract class Notification
case class Email(sender: String, title: String, body: String) extends Notification
case class SMS(caller: String, message: String) extends Notification
case class VoiceRecording(contactName: String, link: String) extends Notification

//基于样例类的模式匹配
def showNotification(notification: Notification): String = {
  notification match {
    case Email(email, title, _) =>
      s"You got an email from $email with title: $title"
    case SMS(number, message) =>
      s"You got an SMS from $number! Message: $message"
    case VoiceRecording(name, link) =>
      s"you received a Voice Recording from $name! Click the link to hear it: $link"
  }
}
val someSms = SMS("12345", "Are you there?")
val someVoiceRecording = VoiceRecording("Tom", "voicerecording.org/id/123")
println(showNotification(someSms))  //结果：You got an SMS from 12345! Message: Are you there?
println(showNotification(someVoiceRecording))  //结果：you received a Voice Recording from Tom! Click the link to hear it: voicerecording.org/id/123
```

#### 6.1.2.带守卫的模式

增加布尔表达式或者条件表达式使得匹配更具体。

```scala
def showImportantNotification(notification: Notification, importantPeopleInfo: Seq[String]): String = {
  notification match {
  //仅匹配email在importantPeople列表里的内容
    case Email(email, _, _) if importantPeopleInfo.contains(email) =>
      "You got an email from special someone!"
    case SMS(number, _) if importantPeopleInfo.contains(number) =>
      "You got an SMS from special someone!"
    case other =>
      showNotification(other) // nothing special, delegate to our original showNotification function
  }
}

val importantPeopleInfo = Seq("867-5309", "jenny@gmail.com")

val someSms = SMS("867-5309", "Are you there?")
val someVoiceRecording = VoiceRecording("Tom", "voicerecording.org/id/123")
val importantEmail = Email("jenny@gmail.com", "Drinks tonight?", "I'm free after 5!")
val importantSms = SMS("867-5309", "I'm here! Where are you?")

println(showImportantNotification(someSms, importantPeopleInfo))
println(showImportantNotification(someVoiceRecording, importantPeopleInfo))
println(showImportantNotification(importantEmail, importantPeopleInfo))
println(showImportantNotification(importantSms, importantPeopleInfo))
```

#### 6.2.5.类型匹配

可以对表达式类型进行匹配：

```scala
    val arr = Array("hs", 1, 2.0, 'a')
    val obj = arr(Random.nextInt(4))
    println(obj)
    obj match {
      case x: Int => println(x)
      case s: String => println(s.toUpperCase)
      case _: Double => println(Int.MaxValue)
      case _ => 0
    }
```

注意：  当你在匹配类型的时候，必须给出一个变量名，否则你将会拿对象本身来进行匹配：

~~~scala
obj match {
  case _: BigInt => Int.MaxValue  // 匹配任何类型为BigInt的对象
  case BigInt => -1              // 匹配类型为Class的BigInt对象
}
~~~

 匹配发生在运行期，Java虚拟机中泛型的类型信息是被擦掉的。因此，你不能用类型来匹配特定的Map类型。

~~~scala
case m: Map[String, Int] => ...   // error
// 可以匹配一个通用的映射
case m: Map[_, _] => ...   // OK

// 但是数组作为特殊情况，它的类型信息是完好的，可以匹配到Array[Int]
case m: Array[Int] => ...   // OK
~~~

#### 6.1.3.匹配数组、列表、元组

数组匹配

```scala
  val arr1 = Array(1,1)
  val res = arr1 match {
  case Array(0) => "0"
  //匹配包含0的数组
  case Array(x, y) => s"$x $y"
  // 匹配任何带有两个元素的数组，并将元素绑定到x和y
  case Array(0, _*) => "0..."
  //匹配任何以0开始的数组
  case _ => "something else"
}
```

列表匹配

```scala
val lst = List(1,2)
val res2 =  list match {
   case 0 :: Nil => "0"
   case x :: y :: Nil => x + " " + y
   case 0 :: tail => "0 ..."
   case _ => "something else"
 }
```

元组匹配

```scala
var pair = (1,2)
val res3 =  pair match {
  case (0, _)  => "0 ..."
  case (y, 0) => s"$y 0"
  case _ => "neither is 0"
}
```

#### 6.1.4.Sealed 类(密封类，备选）

Scala中，Traits 和classes可以被关键字`sealed`修饰， 修饰，被该关键字修饰后，它所有的子类都必须在同一文件中被定义。

这样做的好处是：当你用样例类来做模式匹配时，你可以让编译器确保你已经列出了所有可能的选择，编译器可以检查模式语句的完整性。

```scala
sealed abstract class Furniture
case class Couch() extends Furniture
case class Chair() extends Furniture
//此时无需定义能匹配所有的类型了
def findPlaceToSit(piece: Furniture): String = piece match {
  case a: Couch => "Lie on the couch"
  case b: Chair => "Sit on the chair"
}
```

### 6.2.样例类

在Scala中样例类是一中特殊的类，样例类是不可变的，可以通过值进行比较，可用于模式匹配。

定义一个样例类：

```scala
case class Point(x: Int, y: Int)
```

创建样例类对象：

```scala
val point = Point(1, 2)
val anotherPoint = Point(1, 2)
val yetAnotherPoint = Point(2, 2)
```

通过值对样例类对象进行比较：

```scala
if (point == anotherPoint) {
  println(point + " and " + anotherPoint + " are the same.")
} else {
  println(point + " and " + anotherPoint + " are different.")
}
// Point(1,2) 和 Point(1,2)一样的.

if (point == yetAnotherPoint) {
  println(point + " and " + yetAnotherPoint + " are the same.")
} else {
  println(point + " and " + yetAnotherPoint + " are different.")
}
// Point(1,2)和Point(2,2)是不同的.
```

在模式匹配中使用样例类：

```scala
abstract class Amount
// 继承了普通类的两个样例类
case class Dollar(value: Double) extends Amount
case class Currency(value: Double, unit: String) extends Amount
case object Nothing extends Amount
object CaseClassDemo {

  def main(args: Array[String]): Unit = {
    val amt = new Dollar(10);
    patternMatch(amt)
  }
  def patternMatch(amt: Amount) {
    amt match {
      case Dollar(v) => println("$" + v)
      case Currency(_, u) => println("Oh noes, I got " + u)
      case Nothing => println("nothing") //样例对象没有()
    }
  }
}

```

声明样例类 ，以下几件事会自动发生：

1. 构造器中每一个参数都是val,除非显示地声明为var  
2. 伴生对象提供apply ，让你不使用new关键字就能构造出相应的对象
3. 提供unapply方法，让模式匹配可以工作  
4. 生成toString equals hashCode copy 方法，除非显示给出这些方法的定义。

### 6.3.Option类型

在Scala中Option类型样例类用来表示可能存在或也可能不存在的值(Option的子类有Some和None)。Some包装了某个值，None表示没有值。

```scala
object OptionDemo {
  def main(args: Array[String]) {
    val map = Map("a" -> 1, "b" -> 2)
    val v = map.get("b") match {
      case Some(i) => i
      case None => 0
    }
    println(v)
    //更好的方式
    val v1 = map.getOrElse("c", 0)
    println(v1)
  }
}

```

### 6.4.偏函数

被包在花括号内没有match的一组case语句是一个偏函数，它是PartialFunction[A, B]的一个实例，A代表参数类型，B代表返回类型，常用作输入模式匹配

```scala
object PartialFunctionDemo {
  def f: PartialFunction[String, Int] = {
    case "one" => 1
    case "two" => 2
   // case _ => -1
  }

  def main(args: Array[String]) {
    //调用f.apply("one")
    println(f("one"))
    println(f.isDefinedAt("three"))
    //抛出MatchError
    println(f("three"))
  }
}

```

### 6.5.String INTERPOLATION(字符串插值)(备选)

用途：处理字符串 
类型：

- s：字符串插值 
- f：插值并格式化输出
- raw：对字符串不作任何变换的输出

Scala 2.10.0之后,引入一种新的创建字符串的机制,即 String Interpolation. 它允许用户直接在字符串中嵌入变量的引用。

```scala
val name="James"
println(s"Hello,$name") // Hello, James
```

字符串插值的位置也可以放表达式,如下:

```scala
println(s"1 + 1 = ${1 + 1}")// 1 + 1 = 2
```

插值f 可以对字符串进行格式化,类似printf:

```scala
val height = 1.9d
val name = "James"
println(f"$name%s is $height%2.2f meters tall")  // James is 1.90 meters tall
```

raw类似于s，但是raw对字符串内容不作任何的转换:

```scala
scala> s"a\nb"
res0: String =
a
b
```

```scala
scala> raw"a\nb"
res1: String = a\nb
```

## 7.文件以及正则表达式(备选)

### 7.1 读取行

导入scala.io.Source后，即可引用Source中的方法读取文件信息。

```scala
import scala.io.Source
object FileDemo extends App{
  val source = Source.fromFile("C:/Users/admin/res.txt")
    //返回一个迭代器
  val lines = source.getLines()
  for(i <- lines)
    println(i)
     //内容也可以放到数组中 
//  val arr = source.getLines().toArray
//  for(elem <- arr)
//    println(elem)
     //文件内容直接转换成一个字符串 
//  val contents = source.mkString
//  println(contents)
}
```

### 7.2 读取字符

按字符读取文件中的内容

```scala
import scala.io.Source
object FileDemo extends App{
  val source = Source.fromFile("C:/Users/admin/res.txt")
  for(c <- source)
    println(c)
}
```

### 7.3 读取单词

把文件中的内容,转换成一个单词的数组

```scala
import scala.io.Source
object FileDemo extends App{
  val source = Source.fromFile("C:/Users/admin/res.txt")
  val contents = source.mkString.split(" ")
  for(word <- contents)
  println(word)
}
```

### 7.4 读取网络文件

Source可以直接读取来自URL等非文件源的内容

```scala
import scala.io.Source
object FileDemo extends App{
  val source = Source.fromURL("http://www.baidu.com")
  val lines = source.getLines()
  for(i <- lines)
    println(i)
}
```

### 7.5 写文件

scala 没有内建的对写入文件的支持，要写入文件，使用Java.io.PrintWriter

~~~scala
val out = new PrintWriter("numbers.txt")
for(i <- 1 to 100) out.println(i)
out.close
~~~

### 7.6 正则表达式

构造一个Regex对象,用String类的r方法或者使用new Regex(" ")

如果正则表达式中包含反斜杠或者引号的化,可以使用""" """

```scala
object RegexDemo extends App{
    //构建一个正则表达式
  val numPattern ="[0-9]+".r
    //val numPattern = new Regex("abl[ae]\\d+")
    //构建一个字符串
  val matchStr ="98 bottles,99bottles"
    //使用findAllIn方法返回所有匹配项的迭代器
  for (matchStr <- numPattern.findAllIn(matchStr))
    println(matchStr)//98 99
    //使用""" """"构造含有特殊字符的正则表达式
  val wsnumPattern ="""\s+[0-9]+\s+"""
    //调用findFirstIn方法返回首个匹配项
  val first = numPattern.findFirstIn(matchStr)
  println(first) //Some(98)
    //调用findPrefixOf方法返回字符串的开始部分是否能匹配
  val ifStartMatch = numPattern.findPrefixOf(matchStr)
  println(ifStartMatch)//Some(98)
    //调用replaceFirstIn使用特定的字符串替换首个匹配项
  val res1 = numPattern.replaceFirstIn(matchStr,"xx")
  println(res1)//xx bottles,99bottles
     //调用replaceAllIn使用特定的字符串替换所有的匹配项
  val res2 = numPattern.replaceAllIn(matchStr,"xx")
  println(res2)//xx bottles,xxbottles
}
```

### 7.6 正则表达式组

分组可以让我们方便地获取正则表达式的子表达式。在你想要提取的子表达式两侧加上圆括号

~~~scala
object RegexDemo extends App{
  //数字和字母的组合正则表达式
  val numitemPattern="""([0-9]+) ([a-z]+)""".r
  val line="666 spark"
  for(numitemPattern(num,item) <- numitemPattern.findAllIn(line)){
    println(num+"\t"+item) 
  }
  line match{
    case numitemPattern(num,item)=> println(num+"\t"+item)
    case _=>println("Nothing matched")
  }
}
~~~

