****

# Actor编程

## 回顾：

## 今天任务：

了解并发编程；

了解Scala Actor原理；

学习使用Scala并发编程。

## 教学目标：

了解并发编程；

了解Scala Actor原理；

能运用Scala Actor完成并发编程的任务。

## 1.scala并发编程

### 1.1 Runnable/Callable

Runnable接口只有一个没有返回值的方法。

```scala
trait Runnable {
  def run(): Unit
}
```

Callable与之类似，除了它有一个返回值

```scala
trait Callable[V] {
  def call(): V
}
```

### 1.2 线程

Scala并发是建立在Java并发模型基础上的。

在Sun JVM上，对IO密集的任务，我们可以在一台机器运行成千上万个线程。

一个线程需要一个Runnable。你必须调用线程的 `start` 方法来运行Runnable。

```scala
scala> val hello = new Thread(new Runnable {
  def run() {
    println("hello world")
  }
})
hello: java.lang.Thread = Thread[Thread-3,5,main]

scala> hello.start
hello world
```

当你看到一个类实现了Runnable接口，你就知道它的目的是运行在一个线程中。

### 1.3 单线程代码

这里有一个可以工作但有问题的代码片断。

```scala
import java.net.{Socket, ServerSocket}
import java.util.concurrent.{Executors, ExecutorService}
import java.util.Date

class NetworkService(port: Int, poolSize: Int) extends Runnable {
  val serverSocket = new ServerSocket(port)

  def run() {
    while (true) {
      // This will block until a connection comes in.
      val socket = serverSocket.accept()
      (new Handler(socket)).run()
    }
  }
}

class Handler(socket: Socket) extends Runnable {
  def message = (Thread.currentThread.getName() + "\n").getBytes

  def run() {
    socket.getOutputStream.write(message)
    socket.getOutputStream.close()
  }
}

(new NetworkService(2020, 2)).run
```

每个请求都会回应当前线程的名称，所以结果始终是 `main` 。

这段代码的主要缺点是在同一时间，只有一个请求可以被相应！

你可以把每个请求放入一个线程中处理。只要简单改变

```scala
(new Handler(socket)).run()
```

为

```scala
(new Thread(new Handler(socket))).start()
```

但如果你想重用线程或者对线程的行为有其他策略呢？

### 1.4 Executors

随着Java 5的发布，它决定提供一个针对线程的更抽象的接口。

你可以通过 `Executors` 对象的静态方法得到一个 `ExecutorService` 对象。这些方法为你提供了可以通过各种政策配置的 `ExecutorService` ，如线程池。

下面改写我们之前的阻塞式网络服务器来允许并发请求。

```scala
import java.net.{Socket, ServerSocket}
import java.util.concurrent.{Executors, ExecutorService}
import java.util.Date

class NetworkService(port: Int, poolSize: Int) extends Runnable {
  val serverSocket = new ServerSocket(port)
  val pool: ExecutorService = Executors.newFixedThreadPool(poolSize)

  def run() {
    try {
      while (true) {
        // This will block until a connection comes in.
        val socket = serverSocket.accept()
        pool.execute(new Handler(socket))
      }
    } finally {
      pool.shutdown()
    }
  }
}

class Handler(socket: Socket) extends Runnable {
  def message = (Thread.currentThread.getName() + "\n").getBytes

  def run() {
    socket.getOutputStream.write(message)
    socket.getOutputStream.close()
  }
}

(new NetworkService(2020, 2)).run
```

这里有一个连接脚本展示了内部线程是如何重用的。

```scala
$ nc localhost 2020
pool-1-thread-1

$ nc localhost 2020
pool-1-thread-2

$ nc localhost 2020
pool-1-thread-1

$ nc localhost 2020
pool-1-thread-2
```

### 1.5 Future

`Future` 代表异步计算。你可以把你的计算包装在Future中，当你需要计算结果的时候，你只需调用一个阻塞的 `get()` 方法就可以了。一个 `Executor` 返回一个 `Future` 。

一个 `FutureTask` 是一个Runnable实现，就是被设计为由 `Executor` 运行的

```
val future = new FutureTask[String](new Callable[String]() {
  def call(): String = {
    searcher.search(target);
}})
executor.execute(future)
```

现在我需要结果，所以阻塞直到其完成。

```
val blockingResult = Await.result(future)
```

### 1.6 线程安全问题

```scala
class Person(var name: String) {
  def set(changedName: String) {
    name = changedName
  }
}
```

这个程序在多线程环境中是不安全的。如果有两个线程有引用到同一个Person实例，并调用 `set` ，你不能预测两个调用结束后 `name` 的结果。

### 1.7 三种工具

#### 1.7.1 同步

互斥锁（Mutex）提供所有权语义。当你进入一个互斥体，你拥有它。同步是JVM中使用互斥锁最常见的方式。在这个例子中，我们会同步Person。

在JVM中，你可以同步任何不为null的实例。

```scala
class Person(var name: String) {
  def set(changedName: String) {
    this.synchronized {
      name = changedName
    }
  }
}
```

 

#### 1.7.2 volatile

随着Java 5内存模型的变化，volatile和synchronized基本上是相同的，除了volatile允许空值。

`synchronized` 允许更细粒度的锁。 而 `volatile` 则对每次访问同步。

```scala
class Person(@volatile var name: String) {
  def set(changedName: String) {
    name = changedName
  }
}
```

#### 1.7.3 AtomicReference

此外，在Java 5中还添加了一系列低级别的并发原语。 `AtomicReference` 类是其中之一

```scala
import java.util.concurrent.atomic.AtomicReference

class Person(val name: AtomicReference[String]) {
  def set(changedName: String) {
    name.set(changedName)
  }
}
```

对比

`AtomicReference` 是这两种选择中最昂贵的，因为你必须去通过方法调度（method dispatch）来访问值。

`volatile` 和 `synchronized` 是建立在Java的内置监视器基础上的。如果没有资源争用，监视器的成本很小。由于 `synchronized` 允许你进行更细粒度的控制权，从而会有更少的争夺，所以 `synchronized` 往往是最好的选择。

当你进入同步点，访问volatile引用，或去掉AtomicReferences引用时， Java会强制处理器刷新其缓存线从而提供了一致的数据视图。

### 1.8 Java5的其他灵巧的工具

 **CountDownLatch**

`CountDownLatch` 是一个简单的多线程互相通信的机制。

```scala
val doneSignal = new CountDownLatch(2)
doAsyncWork(1)
doAsyncWork(2)

doneSignal.await()
println("both workers finished!")
```

先不说别的，这是一个优秀的单元测试。比方说，你正在做一些异步工作，并要确保功能完成。你的函数只需要 `倒数计数（countDown）` 并在测试中 `等待（await）` 就可以了。

**AtomicInteger**/Long

由于对Int和Long递增是一个经常用到的任务，所以增加了 `AtomicInteger` 和 `AtomicLong` 。

**AtomicBoolean**

我可能不需要解释这是什么。

**ReadWriteLocks**

`读写锁（ReadWriteLock）` 使你拥有了读线程和写线程的锁控制。当写线程获取锁的时候读线程只能等待。 

### 1.9 构建一个不安全的搜索引擎

下面是一个简单的倒排索引，它不是线程安全的。我们的倒排索引按名字映射到一个给定的用户。

这里的代码假设只有单个线程来访问。

注意使用了 `mutable.HashMap` 替代了默认的构造函数 `this()`

```scala
import scala.collection.mutable

case class User(name: String, id: Int)

class InvertedIndex(val userMap: mutable.Map[String, User]) {

  def this() = this(new mutable.HashMap[String, User])

  def tokenizeName(name: String): Seq[String] = {
    name.split(" ").map(_.toLowerCase)
  }

  def add(term: String, user: User) {
    userMap += term -> user
  }

  def add(user: User) {
    tokenizeName(user.name).foreach { term =>
      add(term, user)
    }
  }
}
```

### 1.10 变为线程安全

在上面的倒排索引例子中，userMap不能保证是线程安全的。多个客户端可以同时尝试添加项目，并有可能出现前面 `Person` 例子中的视图错误。

由于userMap不是线程安全的，那我们怎样保持在同一个时间只有一个线程能改变它呢？

你可能会考虑在做添加操作时锁定userMap。

```scala
def add(user: User) {
  userMap.synchronized {
    tokenizeName(user.name).foreach { term =>
      add(term, user)
    }
  }
}
```

问题是这个粒度太粗了。一定要试图在互斥锁以外做尽可能多的耗时的工作。注意如果不存在资源争夺，锁开销就会很小。如果在锁代码块里面做的工作越少，争夺就会越少。

```scala
def add(user: User) {
  // tokenizeName was measured to be the most expensive operation.
  val tokens = tokenizeName(user.name)

  tokens.foreach { term =>
    userMap.synchronized {
      add(term, user)
    }
  }
}
```

**SynchronizedMap**

我们可以通过SynchronizedMap特质将同步混入一个可变的HashMap。

我们可以扩展现有的InvertedIndex，提供给用户一个简单的方式来构建同步索引。

```scala
import scala.collection.mutable.SynchronizedMap

class SynchronizedInvertedIndex(userMap: mutable.Map[String, User]) extends InvertedIndex(userMap) {
  def this() = this(new mutable.HashMap[String, User] with SynchronizedMap[String, User])
}
```

如果你看一下其实现，你就会意识到，它只是在每个方法上加同步锁来保证其安全性，所以它很可能没有你希望的性能。

**Java ConcurrentHashMap**

Java有一个很好的线程安全的ConcurrentHashMap。值得庆幸的是，我们可以通过JavaConverters获得不错的Scala语义。

事实上，我们可以通过扩展老的不安全的代码，来无缝地接入新的线程安全InvertedIndex。

```scala
import java.util.concurrent.ConcurrentHashMap
import scala.collection.JavaConverters._

class ConcurrentInvertedIndex(userMap: collection.mutable.ConcurrentMap[String, User])
    extends InvertedIndex(userMap) {

  def this() = this(new ConcurrentHashMap[String, User] asScala)
}
```

**加载InvertedIndex**

原始方式

```scala
trait UserMaker {
  def makeUser(line: String) = line.split(",") match {
    case Array(name, userid) => User(name, userid.trim().toInt)
  }
}

class FileRecordProducer(path: String) extends UserMaker {
  def run() {
    Source.fromFile(path, "utf-8").getLines.foreach { line =>
      index.add(makeUser(line))
    }
  }
}
```

对于文件中的每一行，我们可以调用 `makeUser` 然后 `add` 到 InvertedIndex中。如果我们使用并发InvertedIndex，我们可以并行调用add因为makeUser没有副作用，所以我们的代码已经是线程安全的了。

我们不能并行读取文件，但我们 *可以* 并行构造用户并且把它添加到索引中。

**一个解决方案：生产者/消费者**

异步计算的一个常见模式是把消费者和生产者分开，让他们只能通过 `队列（Queue）` 沟通。让我们看看如何将这个模式应用在我们的搜索引擎索引中。

```scala
import java.util.concurrent.{BlockingQueue, LinkedBlockingQueue}

// Concrete producer
class Producer[T](path: String, queue: BlockingQueue[T]) extends Runnable {
  def run() {
    Source.fromFile(path, "utf-8").getLines.foreach { line =>
      queue.put(line)
    }
  }
}

// Abstract consumer
abstract class Consumer[T](queue: BlockingQueue[T]) extends Runnable {
  def run() {
    while (true) {
      val item = queue.take()
      consume(item)
    }
  }

  def consume(x: T)
}

val queue = new LinkedBlockingQueue[String]()

// One thread for the producer
val producer = new Producer[String]("users.txt", q)
new Thread(producer).start()

trait UserMaker {
  def makeUser(line: String) = line.split(",") match {
    case Array(name, userid) => User(name, userid.trim().toInt)
  }
}

class IndexerConsumer(index: InvertedIndex, queue: BlockingQueue[String]) extends Consumer[String](queue) with UserMaker {
  def consume(t: String) = index.add(makeUser(t))
}

// Let's pretend we have 8 cores on this machine.
val cores = 8
val pool = Executors.newFixedThreadPool(cores)

// Submit one consumer per core.
for (i <- i to cores) {
  pool.submit(new IndexerConsumer[String](index, q))
}
```

## 2. Scala future

### 2.1 在Future中运行任务

future提供了一种高效非阻塞方式并行运行多个任务的方式，future是一个可以在未来的某个时间点给你一个结果的对象，是一个可以在未来执行的代码块。

~~~scala
Future{
    Thread.sleep(10000)
    println(s"This is the future at ${LocalTime.now}")
}

println(s"This is the present at ${LocalTime.now}")
~~~

当创建future时，它的代码会在某个线程上执行；

每个future在构造时，必须有一个指向ExecutionContext的引用，ExecutionContext类似于Java中的Executor;

最简单的引入方式是；

~~~
import  ExecutionContext.Implicits.global
~~~

这样任务会在一个全局的线程池中执行。

### 2.2 结果获取

当执行一个Future任务时，可以使用阻塞的调用来等待结果：

~~~scala
import scala.concurrent.duration._
val f =Future{Thread.sleep(10000);88}
val result = Await.result(f,10.seconds)
~~~

如果在分配的时间内任务没有就绪，Await.ready方法抛出TimeoutException。如果任务抛出了异常，该异常会在

Await.result中调用中再次抛出。

使用回调的方式获取执行结果：

~~~scala
import ExecutionContext.Implicits.global
import scala.concurrent.duration._
import scala.util.{Failure, Random, Success}

val f = Future{Thread.sleep(10000)
  if (new Random().nextFloat() < 0.5) throw new Exception
  42
}

f.onComplete{
  case Success(v) => println(s"The answer is $v")
  case Failure(ex) => println(ex.getMessage)
}
~~~

### 2.3 组合Future任务

如果我们需要获取两个任务的执行结果，并将执行结果合并起来，每个任务都是长时间运行的，应该放在Future中执行，组合方式如下：

~~~scala
val future1 = Future{getData1()}
val future2 = Future{getData2()}
val combined = for(n1 <- future1;n2 <- future2) yield n1+n2
~~~

### 2.4 Promise

Future的结果是任务结束或者失败时隐式的被设置的，Promise于Future类似，只是他的结果可以被显式的指定。

~~~scala
def computeAnswer(arg:String) = Future{
    val n = workHard(arg)
    n
}

def computeAnswer(arg:String) = {
val p = Promise[Int]()
Future{
      val n = workHard(arg)
      p.success(n)
      workOnSomethingElse()
}
    p.future
}
~~~

## 3. 了解Scala Actor

注：我们现在学的Scala Actor是scala 2.10.x版本及以前版本的Actor。

Scala在2.11.x版本中将Akka加入其中，作为其默认的Actor，老版本的Actor已经废弃。

### 3.1 什么是 Scala Actor

Scala中的Actor能够实现并行编程的强大功能，它是基于事件模型的并发机制，Scala是运用消息（message）的发送、接收来实现多线程的。使用Scala能够更容易地实现多线程应用的开发。

### 3.2. 对比传统java并发编程与Scala Actor编程 

| Java内置线程模型                                    | scala actor模型                      |
| --------------------------------------------------- | ------------------------------------ |
| “共享数据-锁”模型（share data and lock）            | share nothing                        |
| 每个object有一个monitor，监视多线程对共享数据的访问 | 不共享数据，actor之间通过message通讯 |
| 加锁的代码段用synchronized标识                      |                                      |
| 死锁问题                                            |                                      |
| 每个线程内部是顺序执行的                            | 每个actor内部是顺序执行的            |

对于Java，我们都知道它的多线程实现需要对共享资源（变量、对象等）使用synchronized 关键字进行代码块同步、对象锁互斥等等。而且，常常一大块的try…catch语句块中加上wait方法、notify方法、notifyAll方法是让人很头疼的。原因就在于Java中多数使用的是可变状态的对象资源，对这些资源进行共享来实现多线程编程的话，控制好资源竞争与防止对象状态被意外修改是非常重要的，而对象状态的不变性也是较难以保证的。 而在Scala中，我们可以通过复制不可变状态的资源（即对象，Scala中一切都是对象，连函数、方法也是）的一个副本，再基于Actor的消息发送、接收机制进行并行编程

### 3.3. Actor方法执行顺序

1.首先调用start()方法启动Actor

2.调用start()方法后其act()方法会被执行

3.向Actor发送消息

### 3.4. 发送消息的方式

| !    | 发送异步消息，没有返回值。           |
| ---- | ------------------------------------ |
| !?   | 发送同步消息，等待返回值。           |
| !!   | 发送异步消息，返回值是 Future[Any]。 |

## 4. Actor实战

### 4.1. 第一个例子

```scala
import scala.actors.Actor

object MyActor1 extends Actor{
  //定义act方法
  def act(){
    for(i <- 1 to 10){
      println("actor-1 " + i)
      Thread.sleep(2000)
    }
  }
}

object MyActor2 extends Actor{
  //定义act方法
  def act(){
    for(i <- 1 to 10){
      println("actor-2 " + i)
      Thread.sleep(2000)
    }
  }
}

object ActorExample1 extends App{
  //启动Actor
  MyActor1.start()
  MyActor2.start()
} 
```

说明：上面分别调用了两个单例对象的start()方法，他们的act()方法会被执行，相同与在java中开启了两个线程，线程的run()方法会被执行。

注意：这两个Actor是并行执行的，act()方法中的for循环执行完成后actor程序就退出了

 

### 4.2. 第二个例子

可以不断地接收消息

```scala

import scala.actors.Actor

class ActorExample2 extends Actor {

  override def act(): Unit = {
    while (true) {
      receive {
        case "start" => {
          println("starting ...")
          Thread.sleep(5000)
          println("started")
        }
        case "stop" => {
          println("stopping ...")
          Thread.sleep(5000)
          println("stopped ...")
        }
      }
    }
  }
}

object ActorExample2 {
  def main(args: Array[String]) {
    val actor = new ActorExample2
    actor.start()
    //发送异步消息，感叹号就相当于是一个方法
    actor ! "start"
    actor ! "stop"
    println("消息发送完成！")
  }
}


```

说明：在act()方法中加入了**while **(**true**) 循环，就可以不停的接收消息

注意：发送start消息和stop的消息是异步的，但是Actor接收到消息执行的过程是同步的按顺序执行

 

### 4.3. 第三个例子

react方式会复用线程，比receive更高效

```scala

import scala.actors.Actor

class ActorExample3 extends Actor {

  override def act(): Unit = {
    loop {
      react {
        case "start" => {
          println("starting ...")
          Thread.sleep(5000)
          println("started")
        }
        case "stop" => {
          println("stopping ...")
          Thread.sleep(8000)
          println("stopped ...")
        }
      }
    }
  }
}

object ActorExample3 {
  def main(args: Array[String]) {
    val actor = new ActorExample3
    actor.start()
    actor ! "start"
    actor ! "stop"
    println("消息发送完成！")
  }
}

```



说明： react 如果要反复执行消息处理，react外层要用loop，不能用while

 

### 4.4. 第四个例子

结合case class发送消息

```scala
import scala.actors.Actor

class ActorExample4 extends Actor {

  def act(): Unit = {
    while (true) {
      receive {
        case "start" => println("starting ...")
        case SyncMsg(id, msg) => {
          println(id + ",sync " + msg)
          Thread.sleep(5000)
          sender ! ReplyMsg(3,"finished")
        }
        case AsyncMsg(id, msg) => {
          println(id + ",async " + msg)
          Thread.sleep(5000)
        }
      }
    }
  }
}

object ActorExample4 {
  def main(args: Array[String]) {
    val a = new ActorExample4
    a.start()
    //异步消息
    a ! AsyncMsg(1, "hello actor")
    println("异步消息发送完成")
    //同步消息
    //val content = a.!?(1000, SyncMsg(2, "hello actor"))
    //println(content)
    val reply = a !! SyncMsg(2, "hello actor")
    println(reply.isSet)
    //println("123")
    val c = reply.apply()
    println(reply.isSet)
    println(c)
  }
}
case class SyncMsg(id : Int, msg: String)
case class AsyncMsg(id : Int, msg: String)
case class ReplyMsg(id : Int, msg: String)
```

### 4.5. 练习

用actor并发编程写一个单机版的WorldCount，将多个文件作为输入，计算完成后将多个任务汇总，得到最终的结果。

```scala
import java.io.File

import scala.actors.{Actor, Future}
import scala.collection.mutable
import scala.io.Source

/**
  * Created by ZX on 2016/4/4.
  */
class Task extends Actor {

  override def act(): Unit = {
    loop {
      react {
        case SubmitTask(fileName) => {
          val contents = Source.fromFile(new File(fileName)).mkString
          val arr = contents.split("\r\n")
          val result = arr.flatMap(_.split(" ")).map((_, 1)).groupBy(_._1).mapValues(_.length)
          //val result = arr.flatMap(_.split(" ")).map((_, 1)).groupBy(_._1).mapValues(_.foldLeft(0)(_ + _._2))
          sender ! ResultTask(result)
        }
        case StopTask => {
          exit()
        }
      }
    }
  }
}

object WorkCount {
  def main(args: Array[String]) {
    val files = Array("c://words.txt", "c://words.log")

    val replaySet = new mutable.HashSet[Future[Any]]
    val resultList = new mutable.ListBuffer[ResultTask]

    for(f <- files) {
      val t = new Task
      val replay = t.start() !! SubmitTask(f)
      replaySet += replay
    }

    while(replaySet.size > 0){
      val toCumpute = replaySet.filter(_.isSet)
      for(r <- toCumpute){
        val result = r.apply()
        resultList += result.asInstanceOf[ResultTask]
        replaySet.remove(r)
      }
      Thread.sleep(100)
    }
    val finalResult = resultList.map(_.result).flatten.groupBy(_._1).mapValues(x => x.foldLeft(0)(_ + _._2))
    println(finalResult)
  }
}

case class SubmitTask(fileName: String)
case object StopTask
case class ResultTask(result: Map[String, Int])
```

