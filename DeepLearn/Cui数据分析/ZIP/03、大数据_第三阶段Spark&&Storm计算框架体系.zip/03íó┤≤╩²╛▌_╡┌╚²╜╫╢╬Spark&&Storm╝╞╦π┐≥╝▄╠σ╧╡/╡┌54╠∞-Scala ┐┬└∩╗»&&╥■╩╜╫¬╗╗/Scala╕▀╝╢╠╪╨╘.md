# Scala高级特性

## 回顾：

## 今天任务：

了解高阶函数和隐式转换  。

### 教学目标：

学习使用高阶函数，

学习使用隐式转换。

## 1. 高阶函数

### 1.1. 概念

如果一个函数的传入参数为函数或者返回值是函数，则该函数即为高阶函数。

### 1.2. 传入参数为函数

Scala中，函数是头等公民，和数字一样。不仅可以调用，还可以在变量中存放函数，也可以作为参数传入函数，或者作为函数的返回值。

![](res1.png) 

### 1.3. 传入参数为匿名函数

在Scala中，你不需要给每一个函数命名，就像不必给每个数字命名一样，将函数赋给变量的函数叫做匿名函数

![](res2.png) 

还可以

![](res3.png)

### 1.4. 传入参数为方法（隐式转换方法到函数）

在Scala中，方法和函数是不一样的，最本质的区别是函数可以做为参数传递到方法中

```scala
case class WeeklyWeatherForecast(temperatures: Seq[Double]) {

  private def convertCtoF(temp: Double) = temp * 1.8 + 32
  //方法convertCtoF作为参数传入
  def forecastInFahrenheit: Seq[Double] = temperatures.map(convertCtoF)
}
```

### 1.5.返回值为函数

```scala
//返回值为函数类型：(String, String) => String
def urlBuilder(ssl: Boolean, domainName: String): (String, String) => String = {
  val schema = if (ssl) "https://" else "http://"
  (endpoint: String, query: String) => s"$schema$domainName/$endpoint?$query"
}

val domainName = "www.example.com"
def getURL = urlBuilder(ssl=true, domainName)
val endpoint = "users"
val query = "id=1"
val url = getURL(endpoint, query) // "https://www.example.com/users?id=1": String
```

## 2.方法的嵌套（备选）

方法里嵌套定义其他方法

示例1

```scala
object EmbedDemo {
  
  def add3(x:Int,y:Int,z:Int)={
    def add2(x:Int,y:Int)={
      x+y
    }
    add2(add2(x,y),z)
  }

  def main(args: Array[String]): Unit = {
     println(add3(1,2,3)) //6
  }
}

```

示例2

```scala
def factorial(x: Int): Int = {
def fact(x: Int, accumulator: Int): Int = {
      if (x <= 1) accumulator
      else fact(x - 1, x * accumulator)
    }  
    fact(x, 1)
 }

 println("Factorial of 2: " + factorial(2))
 println("Factorial of 3: " + factorial(3))
```

## 3.方法的多态（备选）

Scala里方法可以通过类型实现参数化，类似泛型。

```scala
def listOfDuplicates[A](x: A, length: Int): List[A] = {
  if (length < 1)
    Nil
  else
    x :: listOfDuplicates(x, length - 1)
}
println(listOfDuplicates[Int](3, 4))  // List(3, 3, 3, 3)
println(listOfDuplicates("La", 8))  // List(La, La, La, La, La, La, La, La)
```

## 4.闭包

 闭包是一个函数，返回值依赖于声明在函数外部的一个或多个变量。

函数体内可以方法相应作用域内的任何变量。

闭包通常来讲可以简单的认为是可以访问一个函数里面局部变量的另外一个函数。

普通函数：

```scala
val multiplier = (i:Int) => i * 10  
```

函数体内有一个变量 i，它作为函数的一个参数。

```scala
val multiplier = (i:Int) => i * factor
```

 在 multiplier 中有两个变量：i 和 factor。其中的一个 i 是函数的形式参数，在 multiplier 函数被调用时，i 被赋予一个新的值。然而，factor不是形式参数，而是自由变量，考虑下面代码：  

```scala
var factor = 3  
val multiplier = (i:Int) => i * factor  
```

这里我们引入一个自由变量 factor，这个变量定义在函数外面。

这样定义的函数变量 multiplier 成为一个"闭包"，因为它引用到函数外面定义的变量，定义这个函数的过程是将这个自由变量捕获而构成一个封闭的函数。

```scala
object Test {  
   def main(args: Array[String]) {  
      println( "muliplier(1) value = " +  multiplier(1) )  
      println( "muliplier(2) value = " +  multiplier(2) )  
   }  
   var factor = 3  
   val multiplier = (i:Int) => i * factor  
}  
```

## 5.柯里化

柯里化是把接受多个参数的函数变换成接受一个单一参数（最初函数的第一个参数）的函数，

并且返回接受余下的参数而且返回结果的新函数的技术。

下面先给出一个普通的非柯里化的函数定义，实现一个加法函数：

```scala
scala> def plainOldSum(x:Int,y:Int) = x + y
plainOldSum: (x: Int, y: Int)Int
scala> plainOldSum(1,2)
res0: Int = 3
```

使用“柯里化”技术，把函数定义为多个参数列表：

```scala
scala> def curriedSum(x:Int)(y:Int) = x + y
curriedSum: (x: Int)(y: Int)Int
scala> curriedSum (1)(2)
res0: Int = 3
```

当你调用 curriedSum (1)(2)时，实际上是依次调用两个普通函数（非柯里化函数），第一次调用使用一个参数 x，返回一个函数类型的值，第二次使用参数y调用这个函数类型的值，我们使用下面两个分开的定义在模拟 curriedSum 柯里化函数：

首先定义第一个函数：

```scala
scala> def first(x:Int) = (y:Int) => x + y
first: (x: Int)Int => Int
```

然后我们使用参数1调用这个函数来生成第二个函数。

```scala
scala> val second=first(1)
second: Int => Int = <function1>
scala> second(2)
res1: Int = 3
```

first，second的定义演示了柯里化函数的调用过程，它们本身和 curriedSum 没有任何关系，但是我们可以使用 curriedSum 来定义 second，如下：

```scala
scala> val onePlus = curriedSum(1)_
onePlus: Int => Int = <function1>
```

下划线“_” 作为第二参数列表的占位符， 这个定义的返回值为一个函数，当调用时会给调用的参数加一。

```scala
scala> onePlus(2)
res2: Int = 3
```

通过柯里化，你还可以定义多个类似 onePlus 的函数，比如 twoPlus

```scala
scala> val twoPlus = curriedSum(2) _
twoPlus: Int => Int = <function1>
scala> twoPlus(2)
res3: Int = 4
```

![](res5.png)
## 5. 隐式转换和隐式参数

### 5.1. 概念

隐式转换和隐式参数是Scala中两个非常强大的功能，利用隐式转换和隐式参数，你可以提供优雅的类库，对类库的使用者隐匿掉那些枯燥乏味的细节。

### 5.2. 作用

隐式的对类的方法进行增强，丰富现有类库的功能

~~~scala
object ImplicitDemo extends App{
  //定义隐式类，可以把File转换成定义的隐式类RichFile
  implicit class RichFile(from:File){
    def read:String = Source.fromFile(from.getPath).mkString
  }
  //使用隐式类做已有类的动能的扩展
  val contents = new File("src/test1.txt").read
  println(contents)

}
~~~

### 5.5. 隐式类

创建隐式类时，只需要在对应的类前加上implicit关键字。比如：

```scala
object Helpers {
  implicit class IntWithTimes(x: Int) {
    def times[A](f: => A): Unit = {
      def loop(current: Int): Unit =
        if(current > 0) {
          f
          loop(current - 1)
        }
      loop(x)
    }
  }
}
```

这个例子创建了一个名为IntWithTimes的隐式类。这个类包含一个int值和一个名为times的方法。要使用这个类，只需将其导入作用域内并调用times方法。比如：

```scala
scala> import Helpers._
import Helpers._
scala> 5 times println("HI")
HI
HI
HI
HI
HI
```

使用隐式类时，类名必须在当前作用域内可见且无歧义，这一要求与隐式值等其他隐式类型转换方式类似。

1. 只能在别的trait/类/对象内部定义。

```scala
    object Helpers {
       implicit class RichInt(x: Int) // 正确！
    }
    implicit class RichDouble(x: Double) // 错误！

```

2. 构造函数只能携带一个非隐式参数。

```scala
 implicit class RichDate(date: java.util.Date) // 正确！
 implicit class Indexer[T](collecton: Seq[T], index: Int) // 错误！
 implicit class Indexer[T](collecton: Seq[T])(implicit index: Index) // 正确！

```

虽然我们可以创建带有多个非隐式参数的隐式类，但这些类无法用于隐式转换。

3. 在同一作用域内，不能有任何方法、成员或对象与隐式类同名。

```scala
object Bar
implicit class Bar(x: Int) // 错误！

val x = 5
implicit class x(y: Int) // 错误！

implicit case class Baz(x: Int) // 错误！
```
### 5.6. 隐式转换函数

是指那种以implicit关键字声明的带有单个参数的函数，这种函数将被自动引用，将值从一种类型转换成另一种类型。

使用隐含转换将变量转换成预期的类型是编译器最先使用 implicit 的地方。这个规则非常简单，当编译器看到类型X而却需要类型Y，它就在当前作用域查找是否定义了从类型X到类型Y的隐式定义。

比如，通常情况下，双精度实数不能直接当整数使用，因为会损失精度：

```scala
scala> val i:Int = 3.5
<console>:7: error: type mismatch;
 found   : Double(3.5)
 required: Int
       val i:Int = 3.5
                   ^
```

当然你可以直接调用 3.5.toInt。

这里我们定义一个从 Double 到 Int 的隐含类型转换的定义，然后再把 3.5 赋值给整数，就不会报错。

```scala
scala> implicit def doubleToInt(x:Double) = x toInt
doubleToInt: (x: Double)Int
scala> val i:Int = 3.5
i: Int = 3
```

此时编译器看到一个浮点数 3.5，而当前赋值语句需要一个整数，此时按照一般情况，编译器会报错，但在报错之前，编译器会搜寻是否定义了从 Double 到 Int 的隐含类型转换，本例，它找到了一个 doubleToInt。 因此编译器将把

```scala
val i:Int = 3.5
```

转换成

```scala
val i:Int = doubleToInt(3.5)
```

这就是一个隐含转换的例子，但是从浮点数自动转换成整数并不是一个好的例子，因为会损失精度。 Scala 在需要时会自动把整数转换成双精度实数，这是因为在 Scala.Predef 对象中定义了一个

```scala
implicit def int2double(x:Int) :Double = x.toDouble
```

而 Scala.Predef 是自动引入到当前作用域的，因此编译器在需要时会自动把整数转换成 Double 类型。

### 5.7. 隐式参数

```scala
object Test{
    trait Adder[T] {
      def add(x:T,y:T):T
    }

    implicit val a = new Adder[Int] {
      override def add(x: Int, y: Int): Int = x+y
    }

    def addTest(x:Int,y:Int)(implicit adder: Adder[Int]) = {
      adder.add(x,y)
    }

   addTest(1,2)      // 正确, = 3
   addTest(1,2)(a)   // 正确, = 3
   addTest(1,2)(new Adder[Int] {
      override def add(x: Int, y: Int): Int = x-y
    })   // 同样正确, = -1
}
```


## 8.泛型类(备选)

带有一个或多个类型参数的类是泛型的。

泛型类的定义：

```scala
 //带有类型参数A的类定义
 class Stack[A] {
  private var elements: List[A] = Nil
     //泛型方法
  def push(x: A) { elements = x :: elements }
  def peek: A = elements.head
  def pop(): A = {
    val currentTop = peek
    elements = elements.tail
    currentTop
  }
}
```

泛型类的使用，用具体的类型代替类型参数A。

```scala
val stack = new Stack[Int]
stack.push(1)
stack.push(2)
println(stack.pop)  // prints 2
println(stack.pop)  // prints 1
```

### 8.1.协变

定义一个类型List[+A]，如果A是协变的，意思是：对类型A和B，A是B的子类型，那么List[A]是List[B]的子类型。

```scala
abstract class Animal {
  def name: String
}
case class Cat(name: String) extends Animal
case class Dog(name: String) extends Animal

```

Scala标准库有一个泛型类sealed abstract class List[+A]，因为其中的类型参数是协变的，那么下面的程序调用时成功的。

```scala
object CovarianceTest extends App {
    //定义参数类型List[Animal]
  def printAnimalNames(animals: List[Animal]): Unit = {
    animals.foreach { animal =>
      println(animal.name)
    }
  }

  val cats: List[Cat] = List(Cat("Whiskers"), Cat("Tom"))
  val dogs: List[Dog] = List(Dog("Fido"), Dog("Rex"))
  //传入参数类型为List[Cat] 
  printAnimalNames(cats)
  // Whiskers
  // Tom
  //传入参数类型为List[Dog] 
  printAnimalNames(dogs)
  // Fido
  // Rex
}
```

### 8.2.逆变

定义一个类型Writer[-A]，如果A是逆变的，意思是：对类型A和B，A是B的子类型，那么Writer[B]是Writer[A]的子类型。

```scala
abstract class Animal {
  def name: String
}
case class Cat(name: String) extends Animal
case class Dog(name: String) extends Animal
```

定义对应上述类进行操作的打印信息类

```scala
abstract class Printer[-A] {
  def print(value: A): Unit
}
class AnimalPrinter extends Printer[Animal] {
  def print(animal: Animal): Unit =
    println("The animal's name is: " + animal.name)
}

class CatPrinter extends Printer[Cat] {
  def print(cat: Cat): Unit =
    println("The cat's name is: " + cat.name)
}
```

逆变的测试

```scala
object ContravarianceTest extends App {
  val myCat: Cat = Cat("Boots")

//定义参数类型为Printer[Cat]
  def printMyCat(printer: Printer[Cat]): Unit = {
    printer.print(myCat)
  }

  val catPrinter: Printer[Cat] = new CatPrinter
  val animalPrinter: Printer[Animal] = new AnimalPrinter

  printMyCat(catPrinter)
    //可以传入参数类型为Printer[Animal] 
  printMyCat(animalPrinter)
}
```

### 8.3.上界

上界定义： `T <: A` ，表示类型变量`T` 必须是 类型`A` 子类

```scala
abstract class Animal {
 def name: String
}

abstract class Pet extends Animal {}

class Cat extends Pet {
  override def name: String = "Cat"
}

class Dog extends Pet {
  override def name: String = "Dog"
}

class Lion extends Animal {
  override def name: String = "Lion"
}
//参数类型须是Pet类型的子类
class PetContainer[P <: Pet](p: P) {
  def pet: P = p
}
//Dog是Pet类型的子类
val dogContainer = new PetContainer[Dog](new Dog)
//Cat是Pet类型的子类
val catContainer = new PetContainer[Cat](new Cat)
//Lion不是Pet类型的子类，编译通不过
//  val lionContainer = new PetContainer[Lion](new Lion)
```

### 8.4.下界

语法 `B >: A` 表示参数类型或抽象类型 `B` 须是类型A的父类。通常，A是类的类型参数，B是方法的类型参数。

![](res6.png)

上面这段代码，因为作为协变类型的B，出现在需要逆变类型的函数参数中，导致编译不通过。解决这个问题，就需要用到下界的概念。

```
trait Node[+B] {
  def prepend[U >: B](elem: U): Node[U]
}

case class ListNode[+B](h: B, t: Node[B]) extends Node[B] {
  def prepend[U >: B](elem: U): ListNode[U] = ListNode(elem, this)
  def head: B = h
  def tail: Node[B] = t
}

case class Nil[+B]() extends Node[B] {
  def prepend[U >: B](elem: U): ListNode[U] = ListNode(elem, this)
}

```

测试

```
trait Bird
case class AfricanSwallow() extends Bird
case class EuropeanSwallow() extends Bird


val africanSwallowList= ListNode[AfricanSwallow](AfricanSwallow(), Nil())
val birdList: Node[Bird] = africanSwallowList
birdList.prepend(new EuropeanSwallow)
```

### 8.5 视界(view bounds)

**注意**:已过时,了解即可

视界定义： `A <% B` ，表示类型变量`A 必须是 类型`B`的子类,或者A能够隐式转换到B

```scala
class Pair_Int[T <% Comparable[T]] (val first: T, val second: T){
  def bigger = if(first.compareTo(second) > 0) first else second
}


class Pair_Better[T <% Ordered[T]](val first: T, val second: T){
  def smaller = if(first < second) first else second
}
object View_Bound {

  def main(args: Array[String]) {
  // 因为Pair[String] 是Comparable[T]的子类型, 所以String有compareTo方法
    val pair = new Pair_Int("Spark", "Hadoop");
    println(pair.bigger)

    /**
      * Scala语言里 Int类型没有实现Comparable;
      * 那么该如何解决这个问题那;
      * 在scala里 RichInt实现了Comparable, 如果我们把int转换为RichInt类型就可以这样实例化了.
      * 在scala里 <% 就起这个作用, 需要修改Pair里的 <: 为<% 把T类型隐身转换为Comparable[Int]
      * String可以被转换为RichString. 而RichString是Ordered[String] 的子类.
      */
    val pair_int = new Pair_Int(3 ,45)
    println(pair_int.bigger)

    val pair_better = new Pair_Better(39 ,5)
    println(pair_better.smaller)

  }

}
```

### 8.6 上下文界定(context bounds)

上下文界定的形式为 T : M, 其中M 必须为泛型类, 必须存在一个M[T]的隐式值.

```scala
class Pair_Context[T : Ordering](val first: T, val second: T){
  def smaller(implicit ord: Ordering[T]) =
    if(ord.compare(first, second) < 0) first else second
}

object Context_Bound {

  def main(args: Array[String]) {

    val pair = new Pair_Context("Spark", "Hadoop")
    println(pair.smaller)

    val int = new Pair_Context(3, 5)
    println(int.smaller)

  }

}
```

