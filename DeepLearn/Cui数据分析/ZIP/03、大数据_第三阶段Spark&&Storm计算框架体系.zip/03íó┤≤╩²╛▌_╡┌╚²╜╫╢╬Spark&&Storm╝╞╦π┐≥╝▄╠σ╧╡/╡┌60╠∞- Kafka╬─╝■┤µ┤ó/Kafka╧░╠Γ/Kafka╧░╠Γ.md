##### kafka的主要组件有哪些？



##### 分区的作用？



##### segment的大小可以设置吗？



##### kafka的文件存储机制？



##### 如何消费已经被消费过的数据？



##### partition和consumer的数量关系？




##### kafka如何分配副本？



##### zookeeper如何管理kafka




##### kafka能否自动创建topics





