##### 1.什么是redis？



##### 2.redis的特点？



##### 3.使用redis有哪些好处?



##### 4.redis相比memcached有哪些优势



##### 5.memcache与redis的区别都有哪些？



##### 6.redis常见性能问题和解决方案



##### 7.redis的并发竞争问题如何解决?



##### 8.redis持久化的几种方式
