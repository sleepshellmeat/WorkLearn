### ELK协议栈详解

#### 回顾

#### 今天任务

```
ELK协议栈介绍
ELK体系结构
ELK的安装及配置
```

#### 教学目标

```
深入理解ELK的应用场景及概念
熟练掌握ELK的安装及配置
```

#### 第一节 简介

​	在我们日常生活中，我们经常需要回顾以前发生的一些事情；或者，当出现了一些问题的时候，可以从某些地方去查找原因，寻找发生问题的痕迹。无可避免需要用到文字的、图像的等等不同形式的记录。用计算机的术语表达，就是 LOG，或日志。

​	日志，对于任何系统来说都是及其重要的组成部分。在计算机系统里面，更是如此。但是由于现在的计算机系统大多比较复杂，很多系统都不是在一个地方，甚至都是跨国界的；即使是在一个地方的系统，也有不同的来源，比如，操作系统，应用服务，业务逻辑等等。他们都在不停产生各种各样的日志数据。根据不完全统计，我们全球每天大约要产生 2EB（1018）的数据。

​	面对如此海量的数据，又是分布在各个不同地方，如果我们需要去查找一些重要的信息，难道还是使用传统的方法，去登陆到一台台机器上查看？看来传统的工具和方法已经显得非常笨拙和低效了。于是，一些聪明人就提出了建立一套集中式的方法，把不同来源的数据集中整合到一个地方。

一个完整的集中式日志系统，是离不开以下几个主要特点的。

- 收集－能够采集多种来源的日志数据
- 传输－能够稳定的把日志数据传输到中央系统
- 存储－如何存储日志数据
- 分析－可以支持 UI 分析
- 警告－能够提供错误报告，监控机制

#### 第二节 市场上的产品

​	基于上述思路，于是许多产品或方案就应运而生了。比如，简单的 Rsyslog，Syslog-ng；商业化的 Splunk ；开源的有 FaceBook 公司的 Scribe，Apache 的 Chukwa，Linkedin 的 Kafak，Cloudera 的 Fluentd，ELK 等等。

在上述产品中，Splunk 是一款非常优秀的产品，但是它是商业产品，价格昂贵，让许多人望而却步。

直到 ELK 的出现，让大家又多了一种选择。相对于其他几款开源软件来说，本文重点介绍 ELK。

#### 第三节 ELK 协议栈介绍及体系结构

​	ELK 其实并不是一款软件，而是一整套解决方案，是三个软件产品的首字母缩写，Elasticsearch，Logstash 和 Kibana。这三款软件都是开源软件，通常是配合使用，而且又先后归于 Elastic.co 公司名下，故被简称为 ELK 协议栈。

![ELK协议栈](ELK协议栈.png)

##### 3.1 Elasticsearch

​	Elasticsearch 是一个实时的分布式搜索和分析引擎，它可以用于全文搜索，结构化搜索以及分析。它是一个建立在全文搜索引擎 Apache Lucene 基础上的搜索引擎，使用 Java 语言编写。目前，最新的版本是 6.2.3。

主要特点

- 实时分析
- 分布式实时文件存储，并将**每一个字段**都编入索引
- 文档导向，所有的对象全部是文档
- 高可用性，易扩展，支持集群（Cluster）、分片和复制（Shards 和 Replicas）。
- 接口友好，支持 JSON
- 实现语言：Java，是开源免费的

集群

![elk集群](elk集群.png)

分片与复制

![e分片与复制](e分片与复制.png)

##### 3.2 Logstash

​	Logstash 是一个具有实时渠道能力的数据收集引擎。使用 JRuby 语言编写。其作者是世界著名的运维工程师乔丹西塞 (JordanSissel)。目前最新的版本是 6.2.3。

主要特点

- 几乎可以访问任何数据
- 可以和多种外部应用结合
- 支持弹性扩展

它由三个主要部分组成：

- Shipper－发送日志数据
- Broker－收集数据，缺省内置 Redis
- Indexer－数据写入

![Logstash 基本组成](Logstash 基本组成.png)

Logstash与Flume的比较：
Logstash：
	安装包体积小而且搭建方便，配置简单
	有数据清洗过滤的功能，通过Filter组件可以实现数据的清洗
	与ES无缝结合
	可以容错：断点续传的功能
	主要用于获取日志数据

Flume：
	在高可用方面是优于Logstash的
	Flume比较看重的是数据传输的安全性，在数据传输的过程通过事务控制的
	多数用于多类型数据的获取

主要组件：
	Logstash：	input	filter	output
	Flume：		source	channel	sink

##### 3.3 Kibana

​	Kibana 是一款基于 Apache 开源协议，使用 JavaScript 语言编写，为 Elasticsearch 提供分析和可视化的 Web 平台。它可以在 Elasticsearch 的索引中查找，交互数据，并生成各种维度的表图。目前最新的版本是 6.2.3，简称 Kibana 6。

国内开发者一般使用替代产品Echarts，百度的开源产品，目前国外开发者也在大量使用。

##### 3.4 ELK 协议栈体系结构

​	完整的 ELK 协议栈体系结构见图 5。基本流程是 Shipper 负责从各种数据源里采集数据，然后发送到 Broker，Indexer 将存放在 Broker 中的数据再写入 Elasticsearch，Elasticsearch 对这些数据创建索引，然后由 Kibana 对其进行各种分析并以图表的形式展示。

![ELK 协议栈体系结构](ELK 协议栈体系结构.png)

​	ELK 三款软件之间互相配合使用，完美衔接，高效的满足了很多场合的应用，并且被很多用户所采纳，诸如路透社，脸书（Facebook），StackOverFlow 等等。

#### 第四节 ELK 的安装及配置

这一部分，我将描述一下如何安装配置 ELK 协议栈。

选取的实验平台为

- Centos 7.1

其中用到的软件如下

- Elasticsearch 使用的是 2.3.1
- Logstash 使用的是 2.3.1
- Kibana 使用的是 4.5.0

**安装前的准备**

- 创建用户 bigdata和组bigdata，以下所有的安装均由这个用户操作，并授予 sudo 权限

  创建bigdata用户

  ```shell
  useradd bigdata
  ```

  设置用户密码

  ```shell
  echo 123456 | passwd --stdin bigdata
  ```

  将bigdata添加到sudoers

  ```shell
  echo "bigdata ALL = (root) NOPASSWD:ALL" | tee /etc/sudoers.d/bigdata
  ```

  修改文件权限

  ```shell
  chmod 0440 /etc/sudoers.d/bigdata
  ```

  解决sudo: sorry, you must have a tty to run sudo问题，在/etc/sudoers注释掉 Default requiretty 一行

  ```shell
  sudo sed -i 's/Defaults    requiretty/Defaults:bigdata !requiretty/' /etc/sudoers
  ```

  切换用户

  ```shell
  su bigdata
  ```

- 创建一个data目录

  在home目录下创建相应目录

  ```shell
  mkdir data
  ```

  给相应的目录赋予权限

  ```shell
  chown -R bigdata:bigdata {bigdata,data}
  ```

##### 4.1 Logstash

###### 4.1.1 安装Logstash

- 首先，下载Logstash，并上传到服务器

  https://www.elastic.co/guide/en/logstash/current/index.html

- 解压

  tar -zxvf logstash-2.3.1.tar.gz -C /bigdata/

- 启动

  ```shell
  bin/logstash -e 'input { stdin {} } output { stdout{} }'
  bin/logstash -e 'input { stdin {} } output { stdout{codec => rubydebug} }'
  bin/logstash -e 'input { stdin {} } output { elasticsearch {hosts => ["192.168.88.211:9200"]} stdout{} }'
  bin/logstash -e 'input { stdin {} } output { elasticsearch {hosts => ["192.168.88.212:9200", "192.168.88.213:9200"]} stdout{} }'

  bin/logstash -e 'input { stdin {} } output { kafka { topic_id => "test1" bootstrap_servers => "192.168.88.81:9092,192.168.88.82:9092,192.168.88.83:9092"} stdout{codec => rubydebug} }'
  ```

###### 4.1.2 配置Logstash

​	我们需要配置 Logstash 以指明从哪里读取数据，向哪里输出数据。这个过程我们称之为定义 Logstash 管道（Logstash Pipeline）。

通常一个管道需要包括必须的输入（input），输出（output），和一个可选项目 Filter。

![Logstash 管道结构示意图](FLogstash 管道结构示意图.png)

标准的管道配置文件格式如下：

```shell
# The # character at the beginning of a line indicates a comment. Use
# comments to describe your configuration.
input {
}
# The filter part of this file is commented out to indicate that it is
# optional.
#filter {
#}
output {
}
```

每一个输入/输出块里面都可以包含多个源。Filter 是定义如何按照用户指定的格式写数据。

**配置 Logstash 管道文件**

###### 4.1.3 配置输出到kafka

```shell
$ cd /home/bigdata/logstash-2.1.1
$ mkdir conf
$ vi conf/logstash-kafka.conf
```

添加以下内容：

```shell
input {
  file {
    path => "/root/data/test.log"
    discover_interval => 5
    start_position => "beginning"
  }
}

output {
    kafka {
	  topic_id => "test1"
	  codec => plain {
        format => "%{message}"
		charset => "UTF-8"
      }
	  bootstrap_servers => "hdp01:9092,hdp02:9092,hdp03:9092"
    }
}
```

- 启动 **Logstash**

  ```shell
  bin/logstash -f conf/logstash-kafka.conf
  ```

###### 4.1.4 配置输出到Elasticsearch

```shell
vi conf/logstash-es.conf

input {
	file {
		type => "gamelog"
		path => "/log/*/*.log"
		discover_interval => 10
		start_position => "beginning" 
	}
}

output {
    elasticsearch {
		index => "gamelog-%{+YYYY.MM.dd}"
        hosts => ["hdp01:9200", "hdp02:9200", "hdp03:9200"]
    }
}
```

- 启动**Logstash**

  ```shell
  bin/logstash -f conf/logstash.conf
  ```

###### 4.1.4 Filter示例

```shell
bin/logstash -e '
input { stdin {} }
filter {
  grok {
    match => { "message" => "%{IP:client} %{WORD:method} %{URIPATHPARAM:request} %{NUMBER:bytes} %{NUMBER:duration}" }
  }
} 
output { stdout{codec => rubydebug} 
}'
```

##### 4.2 Elasticsearch

###### 4.2.1 安装Elasticsearch

步骤一：安装JDK

Elasticsearch 要求至少 Java 7。一般推荐使用 Oracle JDK 1.8 或者 OpenJDK 1.8。

We recommend installing the Java 8 update 20 or later, or Java 7 update 55 or later. 
Previous versions of Java 7 are known to have bugs that can cause index corruption and data loss.
Elasticsearch will refuse to start if a known-bad version of Java is used.

步骤二：安装Elasticsearch

- 上传ES安装包

- 解压ES

  ```
  tar -zxvf elasticsearch-2.3.1.tar.gz -C /bigdata/
  ```

- elasticsearch-2.3.1目录下创建plugins文件夹并添加权限

  ```shell
  mkdir plugins
  chown -R bigdata:bigdata plugins
  ```

- 安装plugin插件

  ```shell
  bin/plugin install mobz/elasticsearch-head
  ```

  此方式受网速限制，建议使用本地方式安装插件：

  ```shell
  ./plugin install file:///home/bigdata/elasticsearch-head-master.zip 
  ```

- 修改配置

  ```shell
  vi /bigdata/elasticsearch-2.3.1/config/elasticsearch.yml
  #集群名称，通过组播的方式通信，通过名称判断属于哪个集群
  cluster.name: bigdata
  #节点名称，要唯一
  node.name: es-1
  #数据存放位置
  path.data: /data/es/data
  #日志存放位置
  path.logs: /data/es/logs
  #es绑定的ip地址
  network.host: 192.168.88.81
  #初始化时可进行选举的节点
  discovery.zen.ping.unicast.hosts: ["hadoop01", "hadoop02", "hadoop03"]
  ```

- 分发软件

  ```shell
  scp -r elasticsearch-2.3.1/ hadoop02:$PWD
  scp -r elasticsearch-2.3.1/ hadoop03:$PWD
  ```

- 修改其他节点的配置，需要修改的有node.name和network.host

- 启动ES

  ```shell
  bin/elasticsearch -h    查看帮助文档
  bin/elasticsearch -d    启动
  ```

- 用浏览器访问ES所在机器的9200端口

  http://192.168.88.81:9200/

  ```json
  {
    "name" : "es-1",
    "cluster_name" : "bigdata",
    "version" : {
      "number" : "2.3.1",
      "build_hash" : "bd980929010aef404e7cb0843e61d0665269fc39",
      "build_timestamp" : "816-04-04T12:25:05Z",
      "build_snapshot" : false,
      "lucene_version" : "5.5.0"
    },
    "tagline" : "You Know, for Search"
  }
  ```

- 杀死ES进程

  ```shell
  kill `ps -ef | grep Elasticsearch | grep -v grep | awk '{print $2}'`
  ```

- 访问head管理页面

  http://192.168.88.81:9200/_plugin/head

- RESTful接口URL的格式

  http://localhost:9200/<index>/<type>/[<id>]
  其中index、type是必须提供的。--->index相当于关系型数据库的dababase,type相当于table
  id是可选的，不提供es会自动生成。
  index、type将信息进行分层，利于管理。
  index可以理解为数据库；type理解为数据表；id相当于数据库表中记录的主键，是唯一的。

###### 4.2.2 操作Elasticsearch数据

- 向store索引中添加一些书籍

  ```shell
  curl -XPUT 'http://192.168.88.81:9200/store/books/1' -d '{
    "title": "Elasticsearch: The Definitive Guide",
    "name" : {
      "first" : "Zachary",
      "last" : "Tong"
    },
    "publish_date":"2015-02-06",
    "price":"49.99"
  }'
  ```

  通过浏览器查询

  http://192.168.88.81:9200/store/books/1

- 在linux中通过curl的方式查询

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/1'
  ```

- 再添加一本书的信息

  ```shell
  curl -XPUT 'http://192.168.88.81:9200/store/books/2' -d '{
    "title": "Elasticsearch Blueprints",
    "name" : {
      "first" : "Vineeth",
      "last" : "Mohan"
    },
    "publish_date":"2015-06-06",
    "price":"35.99"
  }'
  ```

  通过ID获得文档信息

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/2'
  ```

  在浏览器中查看

  http://192.168.88.81:9200/bookstore/books/2

  通过_source获取指定的字段

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/1?_source=title'
  curl -XGET 'http://192.168.88.81:9200/store/books/1?_source=title,price'
  curl -XGET 'http://192.168.88.81:9200/store/books/1?_source'
  ```

- 可以通过覆盖的方式更新

  ```shell
  curl -XPUT 'http://192.168.88.81:9200/store/books/1' -d '{
    "title": "Elasticsearch: The Definitive Guide",
    "name" : {
      "first" : "Zachary",
      "last" : "Tong"
    },
    "publish_date":"2016-02-06",
    "price":"99.99"
  }'
  ```

- 通过 _update  API的方式单独更新你想要更新的

  ```shell
  curl -XPOST 'http://192.168.88.81:9200/store/books/1/_update' -d '{
    "doc": {
       "price" : 88.88
    }
  }'

  curl -XGET 'http://192.168.88.81:9200/store/books/1'
  ```

- 删除一个文档

  ```shell
  curl -XDELETE 'http://192.168.88.81:9200/store/books/1'
  ```

- 最简单filter查询

  filtered 查询价格是35.99的

  SELECT * FROM books WHERE price = 35.99

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/_search' -d '{
      "query" : {
          "filtered" : {
              "query" : {
                  "match_all" : {}
              },
              "filter" : {
                  "term" : {
                      "price" : 35.99
                    }
                }
          }
      }
  }'
  ```

- 指定多个值

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/_search' -d '{
      "query" : {
          "filtered" : {
              "filter" : {
                  "terms" : {
                      "price" : [35.99, 49.99]
                    }
                }
          }
      }
  }'
  ```

- 按时间查询

  SELECT * FROM books WHERE publish_date = "2015-02-06"

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/_search' -d '{
    "query" : {
      "filtered" : {
          "filter" : {
             "term" : {
                "publish_date" : "2015-06-06"
              }
            }
        }
    }
  }'
  ```

- bool过滤查询，可以做组合过滤查询

  SELECT * FROM books WHERE (price = 35.99 OR price = 99.99) AND (publish_date != "2016-02-06")

  类似的，Elasticsearch也有 and, or, not这样的组合条件的查询方式

  格式如下：

  ```shell
  {

  "bool" : {

  "must" :     [],

  "should" :   [],

  "must_not" : [],

  }

  }

  ```

  must: 条件必须满足，相当于 and

  should: 条件可以满足也可以不满足，相当于 or

  must_not: 条件不需要满足，相当于 not

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/_search' -d '{
    "query" : {
      "filtered" : {
        "filter" : {
          "bool" : {
            "should" : [
              { "term" : {"price" : 35.99}},
              { "term" : {"price" : 49.99}}
            ],
  		  "must_not" : {
              "term" : {"publish_date" : "2015-02-06"}
            }
          }
        }
      }
    }
  }'
  ```

- 嵌套查询

  SELECT * FROM books WHERE price = 35.99 OR ( publish_date = "2015-02-06" AND price = 49.99 )

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/_search' -d '{
    "query" : {
      "filtered" : {
        "filter" : {
          "bool" : {
            "should" : [
                { "term" : {"price" : 35.99}},
                { "bool" : {
                "must" : [
                  {"term" : {"publish_date" : "2015-02-06"}},
                  {"term" : {"price" : 49.99}}
                ]
              }}
            ]
          }
        }
      }
    }
  }'
  ```

- range范围过滤

  SELECT * FROM books WHERE price >= 20 AND price < 100

  gt :  > 大于

  lt :  < 小于

  gte :  >= 大于等于

  lte :  <= 小于等于

  会按照字符串来进行比较 20~90

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/_search' -d '{
    "query" : {
      "filtered" : {
        "filter" : {
          "range" : {
            "price" : {
              "gt" : 20.0,
              "lt" : 100
            }
          }
        }
      }
    }
  }'
  ```

- 另外一种 and， or， not查询

  没有bool, 直接使用and , or , not

  注意: 不带bool的这种查询不能利用缓存

  查询价格既是88.88，publish_date又为"2015-02-06"的结果

  ```shell
  curl -XGET 'http://192.168.88.81:9200/store/books/_search' -d '{
    "query": {
      "filtered": {
        "filter": {
          "and": [
          {
            "term": {
              "price":88.88
            }
          },
          {
            "term": {
              "publish_date":"2016-02-06"
            }
          }
         ]
       },
       "query": {
        "match_all": {}
        }
      }
    }
  }'
  ```

##### 4.3 Kibana

###### 4.3.1 安装Kibana

- 下载并上传Kibana到服务器

- 解压

  ```shell
  tar xzvf kibana-4.5.0-linux-x64.tar.gz
  ```

- 修改配置文件

  ```shell
  cd config
  $ vi kibana.yml
  ```

  找到 # server.host，修改成以下：

  ```shell
  server.host:"localhost"
  ```

  配置与Elasticsearch连接：

  ```shell
  server.port: 5601                                      #启动的端口
  server.host: "localhost"                               #绑定IP
  elasticsearch.url: "http://localhost:9200"             #ES地址
  kibana.index: ".kibana"                                #索引名字
  logging.dest: /home/ELK/k/logs/kibana                  #日志目录
  logging.silent: true                                   #输出登录日志
  logging.quiet: true                                    #输出登录错误日志
  ```

- 启动 Kibana

  ```shell
  cd ../bin
  nohup ./kibana &
  […]
   log [07:50:29.926] [info][listening] Server running at http://localhost:5601
  […]
  ```

- 验证 Kibana

  由于我们是配置在 localhost，所以是无法直接访问 Web 页面的。

  可以使用 netstat 来检查缺省端口 5601，或者使用 curl：

  ```shell
  curl localhost:5601
  <script>var hashRoute = '/app/kibana';
  var defaultRoute = '/app/kibana';
   
  var hash = window.location.hash;
  if (hash.length) {
   window.location = hashRoute + hash;
  } else {
   window.location = defaultRoute;
  }</script>
  ```

#### 第五节 结束语

​	本文只是用一个相对简单的例子来阐述 ELK 协议栈在集中式日志的作用。在实际的工作中，其实他们都是可以相对自由组合，这些就不在本文介绍了。

​	另外，ELK 协议栈可以很方便的在大型生产系统中扩充集群以提高性能，比如，使用多个实例来增加 Logstash 的写入能力；如果单个节点的 Elasticsearch 满足不了读取，还可以采用 AMQP 技术来缓冲，等等。

​	ELK 是一个不停发展的产品，希望能够通过本文帮助大家了解它们，并在今后的工作中深入理解。谢谢！



