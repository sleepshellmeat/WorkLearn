##### 1.Elasticsearch是如何实现Master选举的?



##### 2.客户端在和集群连接时，如何选择特定的节点执行请求的？



##### 3.详细描述一下Elasticsearch更新和删除文档的过程



##### 4.详细描述一下Elasticsearch搜索的过程



##### 5.对于GC方面，在使用Elasticsearch时要注意什么？



##### 6.Elasticsearch对于大数据量（上亿量级）的聚合如何实现？



##### 7.在并发情况下，Elasticsearch如果保证读写一致？

