### 标题

#### 回顾

```

```

#### 今天内容

```
1、Storm概述
2、Storm的几个重要角色
3、Storm集群安装与配置
4、Storm集群启动与查看WebUI
5、关于集群的常用操作命令
6、Storm实现单词计数
7、Storm的七种分组策略
8、并发度设置
9、自定义Storm
10、Storm的容错机制
11、数据处理失败导致的数据重复发送问题的解决方式
12、ackfail机制
```

#### 教学目标

```
1、理解Storm几个重要角色的职责
2、掌握Storm集群的安装方法
3、能够用Storm实现WordCount
4、掌握七种分组策略
5、理解Storm的容错机制
6、会使用ackfail机制
```

#### 第一节 Storm概述 

##### 1.1、Storm概述

打开Storm官方主页，查看Storm介绍：http://storm.apache.org/

![storm](storm.png)

##### 1.2、应用场景

```
日志分析：
从海量日志中分析出特定的数据，并将分析的结果存入外部存储器用来辅佐决策。
管道系统：
将一个数据从一个系统传输到另外一个系统，比如将数据库同步到Hadoop
消息转化器：
将接收到的消息按照某种格式进行转化，存储到另外一个系统如消息中间件
```

#### 第二节 Storm的几个重要角色 

##### 2.1、Storm角色

![stormrule](stormrule.png)

```
Nimbus：负责资源分配和任务调度。
Supervisor：负责接受nimbus分配的任务，启动和停止属于自己管理的worker进程。---通过配置文件设置当前supervisor上启动多少个worker。
Worker：运行具体处理组件逻辑的进程。Worker运行的任务类型只有两种，一种是Spout任务，一种是Bolt任务。
Task：worker中每一个spout/bolt的线程称为一个task. 在storm0.8之后，task不再与物理线程对应，不同spout/bolt的task可能会共享一个物理线程，该线程称为executor。
```

##### 2.2、Storm的编程模型

![stormmodule](stormmodule.png)

```
Topology：Storm中运行的一个实时应用程序的名称。（拓扑）
Spout：在一个topology中获取源数据流的组件。通常情况下spout会从外部数据源中读取数据，然后转换为topology内部的源数据。
Bolt：接受数据然后执行处理的组件,用户可以在其中执行自己想要的操作。
Tuple：一次消息传递的基本单元，理解为一组消息就是一个Tuple。
Stream：表示数据的流向。
```

#### 第三节 Storm集群安装与配置 

##### 3.1、下载上传安装包

http://storm.apache.org/downloads.html

##### 3.2、解压安装包

```shell
tar -zxvf apache-storm-0.9.6.tar.gz-C /usr/local/
cd /usr/local
ln -s apache-storm-0.9.6 storm
```

##### 3.3、修改配置文件

```shell
vi /usr/local/storm/conf/storm.yaml
```

输入以下内容：

```shell
#指定storm使用的zk集群
storm.zookeeper.servers:
- "node01"
- "node02"
- "node03"
#指定storm集群中的nimbus节点所在的服务器
nimbus.host: "node01"
#指定nimbus启动JVM最大可用内存大小
nimbus.childopts: "-Xmx1024m"
#指定supervisor启动JVM最大可用内存大小
supervisor.childopts: "-Xmx1024m"
#指定supervisor节点上，每个worker启动JVM最大可用内存大小
worker.childopts: "-Xmx768m"
#指定ui启动JVM最大可用内存大小，ui服务一般与nimbus同在一个节点上。
ui.childopts: "-Xmx768m"
#指定supervisor节点上，启动worker时对应的端口号，每个端口对应槽，每个槽位对应一个worker
supervisor.slots.ports:
- 6700
- 6701
- 6702
- 6703
```

##### 3.4、分发安装包

```shell
scp -r /usr/local/apache-storm-0.9.6 node02:$PWD
cd /usr/local/
ln -s apache-storm-0.9.6 storm
```



#### 第四节 Storm集群启动与查看WebUI 

##### 4.1、启动集群

在nimbus.host所属的机器上启动 nimbus服务

```shell
cd /usr/local/storm/bin/
nohup ./storm nimbus &

```

在nimbus.host所属的机器上启动ui服务

```shell
cd /export/servers/storm/bin/
nohup ./storm ui &
```

在其它个节点上启动supervisor服务

```shell
cd /usr/local/storm/bin/
nohup ./storm supervisor &
```

##### 4.2、查看集群

访问node01:8080，打开Storm的WebUI界面



#### 第五节 关于集群的常用操作命令 

```
有许多简单且有用的命令可以用来管理拓扑，它们可以提交、杀死、禁用、再平衡拓扑。

提交任务命令格式：storm jar 【jar路径】 【拓扑包名.拓扑类名】 【拓扑名称】
bin/storm jar examples/storm-starter/storm-starter-topologies-0.9.6.jar storm.starter.WordCountTopology wordcount

杀死任务命令格式：storm kill 【拓扑名称】 -w 10（执行kill命令时可以通过-w [等待秒数]指定拓扑停用以后的等待时间）
storm kill topology-name -w 10

停用任务命令格式：storm deactivte  【拓扑名称】
storm deactivte topology-name

我们能够挂起或停用运行中的拓扑。当停用拓扑时，所有已分发的元组都会得到处理，但是spouts的nextTuple方法不会被调用。销毁一个拓扑，可以使用kill命令。它会以一种安全的方式销毁一个拓扑，首先停用拓扑，在等待拓扑消息的时间段内允许拓扑完成当前的数据流。

启用任务命令格式：storm activate【拓扑名称】
storm activate topology-name

重新部署任务命令格式：storm rebalance  【拓扑名称】
storm rebalance topology-name
再平衡使你重分配集群任务。这是个很强大的命令。比如，你向一个运行中的集群增加了节点。再平衡命令将会停用拓扑，然后在相应超时时间之后重新分配任务，并重启拓扑。

```



#### 第六节 Storm实现单词计数 

构建驱动类：

```java
import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.topology.TopologyBuilder;

/**
 * 创建一个topology(驱动类),实现单词统计
 * 分三个部分：
 *  Spout：获取数据
 *  Bolt1：切分
 *  Bolt2：对数据做聚合操作
 */
public class WordCountTopology {
    public static void main(String[] args) throws Exception {

        // 调用拓扑构建类
        TopologyBuilder builder = new TopologyBuilder();

        // 调用自定义Spout来随机获取数据
        builder.setSpout("randomgetdataspout", new RandomGetDataSpout(), 1);
        // 调用自定义Bolt来切分数据
        builder.setBolt("splitbolt", new SplitBolt(), 2).shuffleGrouping("randomgetdataspout");
        // 调用自定义Bolt来聚合数据
        builder.setBolt("countbolt", new AggrBolt(), 2).shuffleGrouping("splitbolt");

        // 配置信息类
        Config conf = new Config();

        // 设置是否生成运行日志，
        // 在本地调试时可以设成true，这样可以根据日志观察app运行情况
        // 在生产环境中，一般设成false，以减少性能消耗
        conf.setDebug(false);

        // 两种运行模式，集群模式和本地模式
        if (args != null && args.length > 0) {
            // 设置启动的worker总数
            conf.setNumWorkers(3);
            // 向集群提交任务
            StormSubmitter.submitTopologyWithProgressBar(args[0], conf, uilder.createTopology());
        } else {
            // 设置启动几个线程来模拟Worker
            conf.setMaxTaskParallelism(3);
            // 向本地提交任务
            LocalCluster cluster = new LocalCluster();
            cluster.submitTopology("wc", conf, builder.createTopology());
        }
    }
}

```

实现Spout类：

```java
import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;

import java.util.Map;
import java.util.Random;

/**
 * 调用nextTuple方法，不断的随机生成数据，并把数据发射出去
 */
public class RandomGetDataSpout extends BaseRichSpout {
    // 该队列用来存储生成的数据
    SpoutOutputCollector collector;
    Random rand;

    /**
     * 用来做初始化操作，该方法只会被调用一次
     * @param conf
     * @param context
     * @param collector
     */
    public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
        this.collector = collector;
        rand = new Random();
    }

    /**
     * 相当于有一个上帝之手，调用了一个while循环，不停的调用nextTuple方法
     */
    public void nextTuple() {
        String[] str = new String[]{
                "xiaofang is my goddess",
                "yaoyao is my right girl",
                "xueyan is my love"
        };

        String data = str[rand.nextInt(str.length)];
        collector.emit(new Values(data));
    }

    /**
     * 因为数据可以一次发送多条数据到collector队列里，下游Bolt需要判断到底获取那条数据
     * 此时需要给发送的数据起个名称
     * @param declarer
     */
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("sentence"));
    }
}

```

实现Bolt类：

```java
import backtype.storm.topology.BasicOutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBasicBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

/**
 * 用来切分数据
 */
public class SplitBolt extends BaseBasicBolt {

    /**
     * 将数据切分并发射出去
     * @param input 接收到的数据
     * @param collector 将要把该Bolt处理好的数据发射到此队列
     */
    public void execute(Tuple input, BasicOutputCollector collector) {
        String sentence = input.getString(0);
        String[] words = sentence.split(" ");
        for (String word : words){
            word = word.trim();
            if (word.length() != 0){
                collector.emit(new Values(word, 1));
            }
        }
    }

    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("word", "num"));
    }
}

```

```java
import backtype.storm.topology.BasicOutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBasicBolt;
import backtype.storm.tuple.Tuple;

import java.util.HashMap;
import java.util.Map;

/**
 * 用来聚合数据
 */
public class AggrBolt extends BaseBasicBolt {
    // 用来存储结果数据，key=单词  value=单词出现的次数
    Map<String, Integer> counters = new HashMap<String, Integer>();

    public void execute(Tuple input, BasicOutputCollector collector) {

        String word = (String) input.getValueByField("word");
        int num = (Integer) input.getValueByField("num");

        if (!counters.containsKey(word)){
            counters.put(word, num);
        } else {
            counters.put(word, counters.get(word) + num);
        }

        System.out.println("单词统计结果: " + counters);
    }

    public void declareOutputFields(OutputFieldsDeclarer declarer) {

    }
}

```



#### 第七节 Storm的七种分组策略 

```
Storm里面有7种类型的stream grouping

1、Shuffle Grouping: 随机分组， 随机派发stream里面的tuple，保证每个bolt接收到的tuple数目大致相同。

2、Fields Grouping：按字段分组，比如按userid来分组，具有同样userid的tuple会被分到相同的Bolts里的一个task，而不同的userid则会被分配到不同的bolts里的task。

3、All Grouping：广播发送，对于每一个tuple，所有的bolts都会收到。

4、Global Grouping：全局分组， 这个tuple被分配到storm中的一个bolts的其中一个task。再具体一点就是分配给id值最低的那个task。

5、Non Grouping：不分组，这个stream grouping分组的意思是说stream不关心到底谁会收到它的tuple。目前这种分组和Shuffle grouping是一样的效果， 有一点不同的是storm会把这个bolt放到这个bolt的订阅者同一个线程里面去执行。

6、Direct Grouping： 直接分组， 这是一种比较特别的分组方法，用这种分组意味着消息的发送者指定由消息接收者的哪个task处理这个消息。只有被声明为Direct Stream的消息流可以声明这种分组方法。而且这种消息tuple必须使用emitDirect方法来发射。消息处理者可以通过TopologyContext来获取处理它的消息的task的id （OutputCollector.emit方法也会返回task的id）。

7、Local or shuffle grouping：如果目标bolt有一个或者多个task在同一个工作进程(Worker)中，tuple将会被随机发送给这些tasks。否则，和普通的Shuffle Grouping行为一致。

```



#### 第八节 并发度设置 

![groupingstream](groupingstream.png)

#### 第九节 自定义Storm 

查看mystorm项目代码

#### 第十节 Storm的容错机制 

![ackfail](ackfail.png)

#### 第十一节 数据处理失败导致的数据重复发送问题的解决方式 

```
打开容错机制后，出现数据传输失败，导致的数据重新发送而重复接收的问题：

		execute(){
			1、异常（数据丢失）
			2、任务运行超时，到一定的时间阈值后，系统会认为处理失败
		}
因为数据发送时导致的数据重复发送问题，解决方法？
	1、比如对订单信息做处理，处理成功后，把订单信息Id存储到redis（set(orderId, orderData)）
		信息发送时，判断是否处理过此信息
		execute(){
			if(){
				jedisconn.get(orderId)
			}
			else()
		}
	2、不做处理
		比如用户点击流日志分析：pv、uv、指标分析：订单人数、订单金额
```



#### 第十一节 ackfail机制 

查看ackfail项目代码



#### 总结

```
1、Storm的重要角色
2、实现Storm项目的几个步骤
3、ackfail机制
```

#### 作业

```
自己实现Storm单词计数
```

#### 面试题

```
1、Storm是如何保证数据不丢失的
2、Storm的几种分组策略
```









