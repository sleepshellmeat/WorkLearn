package com.qf.mystorm.core;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public abstract class BaseBolt implements Bolt,Runnable{
    private ArrayBlockingQueue inputQueue;
    public void run() {
        while (true) {
            if (this.inputQueue != null) {
                try {
                    execute((String) inputQueue.take());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void setInputQueue(ArrayBlockingQueue inputQueue) {
        this.inputQueue = inputQueue;
    }
}
