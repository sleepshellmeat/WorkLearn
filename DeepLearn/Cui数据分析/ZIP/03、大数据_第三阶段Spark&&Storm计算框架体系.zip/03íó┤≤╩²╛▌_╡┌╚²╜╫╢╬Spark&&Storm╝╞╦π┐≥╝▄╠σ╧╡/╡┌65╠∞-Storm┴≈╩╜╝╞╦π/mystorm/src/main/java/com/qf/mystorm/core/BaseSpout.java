package com.qf.mystorm.core;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public abstract class BaseSpout implements Spout,Runnable{
    public void run() {
        while (true){
            nextTuple();
        }
    }
}