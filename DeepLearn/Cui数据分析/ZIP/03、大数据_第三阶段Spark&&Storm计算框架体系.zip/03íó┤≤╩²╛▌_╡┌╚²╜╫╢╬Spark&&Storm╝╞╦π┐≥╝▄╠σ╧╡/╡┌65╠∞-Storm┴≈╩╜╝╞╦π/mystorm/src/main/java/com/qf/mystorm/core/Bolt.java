package com.qf.mystorm.core;

import java.util.Map;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public interface Bolt {
    void prepare(Map stormConf, MyContext context, MyOutputCollector collector);
    void execute(String tuple);
}