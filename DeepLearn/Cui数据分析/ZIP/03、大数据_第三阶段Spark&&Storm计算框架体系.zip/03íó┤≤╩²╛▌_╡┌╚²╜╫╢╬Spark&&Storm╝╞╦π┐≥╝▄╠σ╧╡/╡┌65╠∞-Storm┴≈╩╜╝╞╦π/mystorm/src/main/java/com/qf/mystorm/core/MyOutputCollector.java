package com.qf.mystorm.core;

import java.util.concurrent.BlockingQueue;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public class MyOutputCollector {
        private BlockingQueue outputQueue;

    public MyOutputCollector() {
    }

    public MyOutputCollector(BlockingQueue outputQueue) {
        this.outputQueue = outputQueue;
    }

    public void emit(String message) {
        try {
            outputQueue.put(message);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
