package com.qf.mystorm.core;

import java.util.Map;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public interface Spout {
    void open(Map conf, MyContext context, MySpoutOutputCollector collector);
    void nextTuple();

}
