package com.qf.mystorm.wordcount;

import com.qf.mystorm.core.MyTopologyBuilder;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public class DriverMain {
    public static void main(String[] args) {
        MyTopologyBuilder myTopologyBuilder = new MyTopologyBuilder();
        myTopologyBuilder.setSpout("spout", new MySentenceSpout(), 1);
        myTopologyBuilder.setBolt("bolt1", new MySplitBolt(), 2);
        myTopologyBuilder.setBolt("bolt2", new MyWordCountBolt(), 2);
        myTopologyBuilder.setBolt("bolt3", new MyPrintBolt(), 2);
        myTopologyBuilder.submit();
    }
}