package com.qf.mystorm.wordcount;

import com.qf.mystorm.core.BaseBolt;
import com.qf.mystorm.core.MyContext;
import com.qf.mystorm.core.MyOutputCollector;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public class MyPrintBolt extends BaseBolt {
    Map<String, Integer> counters = new HashMap<String, Integer>();
    private MyOutputCollector collector;
    public void prepare(Map stormConf, MyContext context, MyOutputCollector collector) {
        this.collector = collector;
    }

    public void execute(String input) {
        System.out.println(input);
    }
}