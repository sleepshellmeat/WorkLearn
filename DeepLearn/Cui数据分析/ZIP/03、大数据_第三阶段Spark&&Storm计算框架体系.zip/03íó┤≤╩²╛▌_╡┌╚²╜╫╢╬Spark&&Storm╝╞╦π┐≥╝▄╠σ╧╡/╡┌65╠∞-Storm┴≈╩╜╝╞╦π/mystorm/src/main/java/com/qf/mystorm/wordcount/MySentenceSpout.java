package com.qf.mystorm.wordcount;

import com.qf.mystorm.core.BaseSpout;
import com.qf.mystorm.core.MyContext;
import com.qf.mystorm.core.MySpoutOutputCollector;

import java.util.Map;
import java.util.Random;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public class MySentenceSpout extends BaseSpout {
    private MyContext context;
    private MySpoutOutputCollector collector;
    private Random r;
    public void open(Map conf, MyContext context, MySpoutOutputCollector collector) {
        this.context = context;
        this.collector = collector;
        this.r = new Random();
    }

    public void nextTuple() {
        String[] sentences = new String[] {
                "If I had a single flower for every time I think about you, I could walk forever in my garden.",
                "Love is hard to get into, but harder to get out of.",
                "I need him like I need the air to breathe.",
                "At the touch of love everyone becomes a poet.",
                "Look into my eyes - you will see what you mean to me."
        };
        String sentence = sentences[r.nextInt(sentences.length)];
        collector.emit(sentence);
        try {
            Thread.sleep(20);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
