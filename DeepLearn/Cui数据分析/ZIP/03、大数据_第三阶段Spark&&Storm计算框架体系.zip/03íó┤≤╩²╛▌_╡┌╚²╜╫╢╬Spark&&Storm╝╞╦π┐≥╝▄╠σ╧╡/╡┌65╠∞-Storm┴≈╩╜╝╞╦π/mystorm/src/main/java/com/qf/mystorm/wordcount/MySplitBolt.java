package com.qf.mystorm.wordcount;

import com.qf.mystorm.core.BaseBolt;
import com.qf.mystorm.core.MyContext;
import com.qf.mystorm.core.MyOutputCollector;

import java.util.Map;

/**
 * Created by liangdmaster on 2017/2/26.
 */
public class MySplitBolt extends BaseBolt {
    private MyOutputCollector collector;
    public void prepare(Map stormConf, MyContext context, MyOutputCollector collector) {
        this.collector = collector;
    }

    public void execute(String sentence) {
        String[] words = sentence.split(" ");
        for (String word : words) {
            word = word.trim();
            if (!word.isEmpty()) {
                word = word.toLowerCase();
                collector.emit(word);
            }
        }
    }
}
