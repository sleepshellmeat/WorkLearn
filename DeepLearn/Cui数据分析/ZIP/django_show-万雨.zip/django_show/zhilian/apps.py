from django.apps import AppConfig


class ZhilianConfig(AppConfig):
    name = 'zhilian'
