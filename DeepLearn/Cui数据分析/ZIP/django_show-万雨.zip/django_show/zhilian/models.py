from django.db import models

# Create your models here.

class Information(models.Model):
    job_title = models.TextField()
    job_salary = models.TextField()
    job_address = models.TextField()
    job_nature = models.TextField()
    job_experience = models.TextField()
    job_education = models.TextField()
    job_num_people = models.TextField()
    job_content = models.TextField()
    job_classify = models.TextField()



