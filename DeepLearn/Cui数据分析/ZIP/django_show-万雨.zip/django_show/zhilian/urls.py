from django.conf.urls import url
from zhilian import views


urlpatterns = [
    url(r'^$',views.index),
    url(r'^taitan/',views.taitan),
    url(r'^zhilian/',views.zhilian),
    url(r'^search/',views.search),
    url(r'^about/',views.about),
    url(r'^continued/',views.continued),
    #泰坦尼克号
    url(r'^all_survived/',views.all_servived),
    url(r'^age_group_survived/',views.age_group_survived),
    url(r'^age_women_survived/',views.age_women_survived),
    url(r'^cabin_survived/',views.cabin_survived),
    url(r'^kinsfolk_survived/',views.kinsfolk_survived),
    url(r'^men_women_survived/',views.men_women_survived),
    url(r'^port_survived/',views.port_survived),
    #智联招聘
    url(r'^word_cloud/',views.word_cloud),
    url(r'^money_pie/',views.money_pie),
    url(r'^experience_pie/',views.experience_pie),
    url(r'^education_pie/',views.education_pie),
    url(r'^address_pie/',views.address_pie),
    #智联搜索
    url(r'^zhilian_search/',views.zhilian_search),

    #智联分类
    url(r'^zhilian_classify/',views.zhilian_classify),
    url(r'^info_show/(?P<page>\d+)/',views.info_show),
]