from django.shortcuts import render,redirect,reverse
from django.http import HttpResponse,JsonResponse
from zhilian.models import Information
from django.db.models import Q
import math
from sklearn.naive_bayes import MultinomialNB
import pandas as pd
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.externals import joblib
import os

# Create your views here.


def index(request):
    return render(request,'info/index.html')

def taitan(request):
    return render(request,'taitan/survived.html')


def zhilian(request):
    return render(request,'info/zhilian.html')

def search(request):
    return render(request,'info/search.html')

def about(request):
    return render(request,'info/about.html')

def continued(request):
    return render(request,'info/continued.html')

#泰坦尼克号
def all_servived(request):
    return render(request,'taitan/all_survived.html')


def age_group_survived(request):
    return render(request,'taitan/age_group_survived.html')


def age_women_survived(request):
    return render(request,'taitan/age_women_survived.html')


def cabin_survived(request):
    return render(request,'taitan/cabin_survived.html')


def kinsfolk_survived(request):
    return render(request,'taitan/kinsfolk_survived.html')


def men_women_survived(request):
    return render(request,'taitan/men_women_survived.html')


def port_survived(request):
    return render(request,'taitan/port_survived.html')



#智联招聘
def word_cloud(request):
    return render(request,'zhilian/zhilian_word_cloud.html')


def money_pie(request):
    return render(request,'zhilian/zhilian_money_pie.html')


def experience_pie(request):
    return render(request,'zhilian/zhilian_experience_pie.html')


def address_pie(request):
    return render(request,'zhilian/zhilian_address_pie.html')


def education_pie(request):
    return render(request,'zhilian/zhilian_education_pie.html')

def zhilian_address(select_address):
    if select_address == 'None':
        return ''
    elif select_address == 'beijing':
        return '北京'
    elif select_address == 'shanghai':
        return '上海'
    elif select_address == 'guangzhou':
        return '广州'
    elif select_address == 'zhengzhou':
        return '郑州'
    elif select_address == 'shenzhen':
        return '深圳'
    elif select_address == 'hangzhou':
        return '杭州'
    elif select_address == 'nanjing':
        return '南京'
    elif select_address == 'wuhan':
        return '武汉'
    elif select_address == 'chengdu':
        return '成都'
    elif select_address == 'suzhou':
        return '苏州'
    elif select_address == 'jinan':
        return '济南'
    elif select_address == 'xian':
        return '西安'
    else:
        return ''

def zhilian_money(select_money):
    if select_money == 'None':
        return None
    elif select_money == '1k':
        return 1000
    elif select_money == '5k':
        return 5000
    elif select_money == '8k':
        return 8000
    elif select_money == '12k':
        return 12000
    elif select_money == '15k':
        return 15000
    elif select_money == '20k':
        return 20000
    # elif select_money == 'mianyi':
    #     return '面议'
    else:
        return None


#智联搜索
def zhilian_search(request):

    try:
        content = request.GET['content']

    except:
        content=''
    select_zhilian_address = request.GET['select_zhilian_address']
    select_zhilian_money = request.GET['select_zhilian_money']

    try:
        page = request.GET['page']
        # print(type(page))
        page = int(page)
    except:
        page = 0

    address = zhilian_address(select_zhilian_address)
    money = zhilian_money(select_zhilian_money)


    infos = Information.objects.filter(Q(job_title__icontains = content)).filter(Q(job_address__icontains = address))
    infos_list = []
    if money:
        for i in range(len(infos)):
            try:
                if int(infos[i].job_salary.split('-')[0]) >= money :
                    infos_list.append({"id":infos[i].id,
                                       "job_title":infos[i].job_title,
                                       "job_salary": infos[i].job_salary,
                                       "job_address": infos[i].job_address,
                                       "job_experience": infos[i].job_experience,
                                       "job_education": infos[i].job_education,
                                       "job_content": infos[i].job_content
                                       })
            except:
                continue
        infos = infos_list
    else:
        for i in range(len(infos)):
            infos_list.append({"id":infos[i].id,
                               "job_title": infos[i].job_title,
                               "job_salary": infos[i].job_salary,
                               "job_address": infos[i].job_address,
                               "job_experience": infos[i].job_experience,
                               "job_education": infos[i].job_education,
                               "job_content": infos[i].job_content
                               })
        infos = infos_list

    pages = math.ceil(len(infos)/10)


    info_list = []
    try:
        for i in range(10):
            info_list.append({"id":infos[page*10+i]['id'],
                          "job_title":infos[page*10+i]['job_title'],
                          "job_salary":infos[page*10+i]['job_salary'],
                          "job_address":infos[page*10+i]['job_address'],
                          "job_experience":infos[page*10+i]['job_experience'],
                          "job_education":infos[page*10+i]['job_education'],
                          "job_content":infos[page*10+i]['job_content'][0:50]+'....',})
    except:
        info_list = []
        for i in range(len(infos)%10):
            info_list.append({"id":infos[page*10+i]['id'],
                              "job_title": infos[page * 10 + i]['job_title'],
                              "job_salary": infos[page * 10 + i]['job_salary'],
                              "job_address": infos[page * 10 + i]['job_address'],
                              "job_experience": infos[page * 10 + i]['job_experience'],
                              "job_education": infos[page * 10 + i]['job_education'],
                              "job_content": infos[page * 10 + i]['job_content'][0:50] + '....', })

    # print(info_list)
    return JsonResponse({"records":info_list,"page":page,"pages":pages})


def info_show(request,page):
    info = Information.objects.get(id=page)
    return render(request,'info/info_show.html',{'info':info})





def split_str():
    str_list = """mysql
    数据库
    MySQL
    Mysql
    mongodb
    MongoDB
    mongo
    python
    Python
    java
    Java
    JAVA
    WEB
    Web
    web
    Linux
    linux
    Qracle
    SQLServer
    爬虫
    网络
    信息
    安全
    网络爬虫
    大数据
    数据
    分析
    实习
    助理
    人工智能
    人工
    智能
    ai
    AI
    前端
    后端
    后台
    全栈
    中级
    初级
    高级
    讲师
    教师
    老师
    C++
    C
    c
    c++
    C#
    c#
    测试
    研发
    服务器
    系统
    ui
    算法
    运维
    架构
    ETL
    游戏
    语言
    语音
    建模
    UI
    顾问
    学徒
    量化
    研究
    策略
    DNS
    生物
    NLP
    it
    IT
    IDC
    视觉
    专家
    自动化
    自动
    云计算
    计算
    .net
    ROS
    棋牌
    """
    str_list = str_list.splitlines()
    str_str = []
    for i in str_list:
        str_str.extend(i.split())
    return str_str

def cutword(title,content):
    title_list = []
    for i in range(len(title)):
        aa = list(jieba.cut(title[i]))
        bb = list(jieba.cut(content[i]))
        dd = []
        for j in bb:
            if j in split_str():
                dd.append(j)
        cc = ''
        cc = ' '.join(aa) + ' ' + ' '.join(dd)
        title_list.append(cc)
    return title_list

#智联分类
def zhilian_classify(request):
    # print(request.GET['content'])
    content = list(jieba.cut(request.GET['content']))
    content = ' '.join(content)

    # infos = Information.objects.all()
    # x_t,x_c,y = [],[],[]
    # for i in range(330):
    #     x_t.append(infos[i].job_title)
    #     x_c.append(infos[i].job_content)
    #     y.append(infos[i].job_classify)
    # x = cutword(x_t,x_c)
    # tfidf_transformer = TfidfVectorizer()
    # X_train_tfidf = tfidf_transformer.fit_transform(x)

    # 保存模型
    # joblib.dump(tfidf_transformer,'tfidf_model.pkl')

    # clf = MultinomialNB(alpha=1.0)
    # clf.fit(X_train_tfidf, y)
    # 保存模型
    # joblib.dump(clf, 'clf_model.pkl')

    # 载入训练好的模型模型
    clf = joblib.load('clf_model.pkl')
    tfidf_transformer = joblib.load('tfidf_model.pkl')

    X_new_tfidf = tfidf_transformer.transform([content,])
    predicted = clf.predict(X_new_tfidf)

    return JsonResponse({'job_title':predicted[0]})

