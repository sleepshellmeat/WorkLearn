from lib.orm import patch_model

# 给 Model 打补丁
patch_model()
