from django.apps import AppConfig


class VipConfig(AppConfig):
    name = 'vip'
