# encoding=utf-8
import pandas as pd
from pylab import mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager

#在数据挖掘前一个数据分析、筛选、清理的多功能工具

#将excel读取并转换为pandas的DataFrame
#pd.read_csv读取CSV文件
#创建一个默认索引从0开始的Series
s = pd.Series([1,2,3,4,5,6])
#创建一个自定义索引的数组，索引由index指定，和前面数组依次对应
s = pd.Series([1,2,3,4,5,6],index=['a','b','c','d','e','f'])
#使用字典创建一个DataFrame，字典的Key会自动成为索引,一个Key默认对应一列数据
df1 = pd.DataFrame({'math':[1,2,3,4,5],'physic':[5,6,7,8,9]})
#提取头两行,参数指定从开始读取多少行
df1.head(2)
#提取结尾数据,参数指定从结尾开始多少行
df1.tail(2)
#生成从20180101开始的时间序列,默认增加单位是天
dates = pd.date_range('20180101',periods=10)
#创建使用时间索引的Series
s_date= pd.Series(range(10), index=dates)
#取出从2018-01-01到2018-01-06的行数据
s_date['2018-01-01':'2018-01-06']

df_imdb = pd.read_csv('IMDB.csv')
#查看数据基本信息
df_imdb.info()
#选出一列
df_imdb.Title #相当于df_imdb['Title']
#获取最高票房
df_imdb['Revenue (Millions)'].max()
df_imdb['Revenue (Millions)'].sum()
df_imdb['Revenue (Millions)'].idxmax()#返回最大值的索引
#将DataFrame第50行数据的Director列取出,[]去1：6的数据的时候不会把6取出来
df_imdb[50:51]['Director']
#第一个纬度是行，第二维度是列,将50到56行(包含50行和56行自身)的导演和年份取出
df_imdb.loc[50:56,['Director','Year']]
#将1到10行(不包含第10行)，及2到3列(不包含第3列)取出，使用整数索引操作
df_imdb.iloc[1:10,2:3]
#统计Director列中不同导演出现的次数
df_imdb['Director'].value_counts()
#将票房大于5亿美元的电影选出来,支持> < ==
df_imdb[df_imdb['Revenue (Millions)'] > 500]
#将电影风格描述中含有Sci-Fi（科幻）关键字的找出,str将待处理列转换为字符串
df_imdb[df_imdb['Genre'].str.contains('Sci-Fi')]
#将缺失数据(NaN)填充为0，也可以自己根据项目需求指定其他数据
df_score.fillna(0)
#将缺失数据的行移除(默认操作,可以使用axis=1指定删除列df_score.dropna(axis=1),0:按行,1:按列)
df_score.dropna()

#加载excel文件
df_score = pd.read_excel('score.xlsx')
#在DataFrame增加一列avg(平均值),计算当前DataFrame中每一行的平均值作为avg的数据,前后赋值数据的
#行数要对应,axis=1表示按照行计算平均值,axis=0(默认值)，表示按列计算
df_score['avg'] = df_score.mean(axis=1)
#为成绩表添加一个新列，计算总分
df_score['sum'] = df_score.sum(axis=1)
#选出音乐、性别字段，按照性别分组，进一步计算各个分组的总和
df_score.loc[:,[u'音乐',u'性别']].groupby(u'性别').sum()
#将数学成绩大于80或化学成绩大于60的同学选出
df_score[(df_score[u'数学'] > 80) | (df_score[u'化学'] > 60)]
#使用lambda，配合apply方法将日期中的年份提取出来
#apply函数会将lambda一次作用到数据集的每个元素
dates = pd.Series(['20190901','20190902','20190903'])
dates.apply(lambda x:x[0:4])
#创建一个数据的副本
df_copy = df_score.copy()
#计算数学列的总和、平均值、最大值、方差，里面的字符串必须有同名函数
df_score[u'数学'].agg(['sum','mean','max','std'])
#将pandas类型转换为numpy类型
df_score.loc[:,[u'数学',u'化学']].values

#对新添加的sum(总分)按照降序进行排序，False：降序(由大到小)，默认是升序(由小到大)
df_score['sum'].sort_values(ascending=False)
#取出Embarked，Survived字段，按照两个字段的顺序(重要!!!!)做层次分组，然后计算总和
df_score.loc[:,['Embarked','Survived']].groupby(['Embarked','Survived']).size()

